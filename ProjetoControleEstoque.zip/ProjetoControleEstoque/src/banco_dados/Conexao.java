/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_dados;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Lucas Corrêa
 */
public class Conexao {
     
    public static Connection connection;
    static String url = "jdbc:postgresql://localhost:5434/banco_dados";
    static String user = "postgres";
    static String pass = "1234";
    public ResultSet rs;
    
    public static Connection Conectar(){
        try{
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(url, user, pass);
            //System.out.println("Conexão realizada com sucesso");
            //JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso");
        }
        catch(SQLException ex){
            System.out.println("Problemas na conexão com o banco de dados. "+ex);
        }
        catch(ClassNotFoundException ex){
            System.out.println("Driver JDBC-ODBC não encontrado: "+ex);
        }
        return connection;
    }
    
    public static void Fechar() throws SQLException{
        connection.close();
        System.out.println("Conexão finalizada com sucesso");
    }
    
    public void executaSQL(String sql){
        try{
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs = statement.executeQuery(sql);
        }catch (SQLException excecao){
            JOptionPane.showMessageDialog(null,"\nERRO NO COMANDO SQL!\nErro" + excecao + "" +
                 "\nCOMANDO SQL PASSADO" + sql);
            
        }
    
    }
    
    public static void closeConnection(Connection con, PreparedStatement stmt, ResultSet rs) {

        //closeConnection(con, stmt);

        try {

            if (rs != null) {
                rs.close();
            }

        } catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

}
    

