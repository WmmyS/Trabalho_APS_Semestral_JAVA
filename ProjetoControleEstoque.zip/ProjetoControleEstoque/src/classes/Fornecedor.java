/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Lucas Corrêa
 */
public class Fornecedor {
    int tipoFornecedor;
    int codigoFornecedor;
    String nomeFornecedor;
    String emailFornecedor;
    String apelidoFornecedor;
    String enderecoFornecedor;
    String bairroFornecedor;
    String cidadeFornecedor;
    String estadoFornecedor;    
    String cepFornecedor;
    String telefone1Fornecedor;
    String telefone2Fornecedor;
    String dataNascimentoFornecedor;
    String cpfFornecedor;
    String rgFornecedor;
    String cnpjFornecedor;;
    String ieFornecedor;

    public int getCodigoFornecedor() {
        return codigoFornecedor;
    }

    public void setCodigoFornecedor(int codigoFornecedor) {
        this.codigoFornecedor = codigoFornecedor;
    }

    
    
    
    public String getCpfFornecedor() {
        return cpfFornecedor;
    }

    public void setCpfFornecedor(String cpfFornecedor) {
        this.cpfFornecedor = cpfFornecedor;
    }

    public String getRgFornecedor() {
        return rgFornecedor;
    }

    public void setRgFornecedor(String rgFornecedor) {
        this.rgFornecedor = rgFornecedor;
    }

    public String getCnpjFornecedor() {
        return cnpjFornecedor;
    }

    public void setCnpjFornecedor(String cnpjFornecedor) {
        this.cnpjFornecedor = cnpjFornecedor;
    }

    public String getIeFornecedor() {
        return ieFornecedor;
    }

    public void setIeFornecedor(String ieFornecedor) {
        this.ieFornecedor = ieFornecedor;
    }


    public int getTipoFornecedor() {
        return tipoFornecedor;
    }

    public void setTipoFornecedor(int tipoFornecedor) {
        this.tipoFornecedor = tipoFornecedor;
    }


       
    public String getEstadoFornecedor() {
        return estadoFornecedor;
    }

    public void setEstadoFornecedor(String estadoFornecedor) {
        this.estadoFornecedor = estadoFornecedor;
    }
    
    
    public String getEmailFornecedor() {
        return emailFornecedor;
    }

    public void setEmailFornecedor(String emailFornecedor) {
        this.emailFornecedor = emailFornecedor;
    }

    public String getApelidoFornecedor() {
        return apelidoFornecedor;
    }

    public void setApelidoFornecedor(String apelidoFornecedor) {
        this.apelidoFornecedor = apelidoFornecedor;
    }

    public String getEnderecoFornecedor() {
        return enderecoFornecedor;
    }

    public void setEnderecoFornecedor(String enderecoFornecedor) {
        this.enderecoFornecedor = enderecoFornecedor;
    }

    public String getBairroFornecedor() {
        return bairroFornecedor;
    }

    public void setBairroFornecedor(String bairroFornecedor) {
        this.bairroFornecedor = bairroFornecedor;
    }

    public String getCidadeFornecedor() {
        return cidadeFornecedor;
    }

    public void setCidadeFornecedor(String cidadeFornecedor) {
        this.cidadeFornecedor = cidadeFornecedor;
    }

    public String getCepFornecedor() {
        return cepFornecedor;
    }

    public void setCepFornecedor(String cepFornecedor) {
        this.cepFornecedor = cepFornecedor;
    }

    public String getTelefone1Fornecedor() {
        return telefone1Fornecedor;
    }

    public void setTelefone1Fornecedor(String telefone1Fornecedor) {
        this.telefone1Fornecedor = telefone1Fornecedor;
    }

    public String getTelefone2Fornecedor() {
        return telefone2Fornecedor;
    }

    public void setTelefone2Fornecedor(String telefone2Fornecedor) {
        this.telefone2Fornecedor = telefone2Fornecedor;
    }

    public String getDataNascimentoFornecedor() {
        return dataNascimentoFornecedor;
    }

    public void setDataNascimentoFornecedor(String dataNascimentoFornecedor) {
        this.dataNascimentoFornecedor = dataNascimentoFornecedor;
    }


    public String getNomeFornecedor() {
        return nomeFornecedor;
    }

    public void setNomeFornecedor(String nomeFornecedor) {
        this.nomeFornecedor = nomeFornecedor;
    }
    
    
    
}
