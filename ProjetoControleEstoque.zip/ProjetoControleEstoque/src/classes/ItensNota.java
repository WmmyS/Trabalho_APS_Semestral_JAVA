/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Lucas Corrêa
 */
public class ItensNota {
    
    int codNota;
    int codFornecedor;
    int codMercadoria;
    int qtdeProduto;
    float valorAp;
    float valorVp;
    
    

    public int getCodNota() {
        return codNota;
    }

    public void setCodNota(int codNota) {
        this.codNota = codNota;
    }

    public int getCodFornecedor() {
        return codFornecedor;
    }

    public void setCodFornecedor(int codFornecedor) {
        this.codFornecedor = codFornecedor;
    }
    
    
    
    

    public int getCodMercadoria() {
        return codMercadoria;
    }

    public void setCodMercadoria(int codMercadoria) {
        this.codMercadoria = codMercadoria;
    }

    public int getQtdeProduto() {
        return qtdeProduto;
    }

    public void setQtdeProduto(int qtdeProduto) {
        this.qtdeProduto = qtdeProduto;
    }

    public float getValorAp() {
        return valorAp;
    }

    public void setValorAp(float valorAp) {
        this.valorAp = valorAp;
    }

    public float getValorVp() {
        return valorVp;
    }

    public void setValorVp(float valorVp) {
        this.valorVp = valorVp;
    }
    
    
    
}
