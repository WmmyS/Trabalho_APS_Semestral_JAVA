/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Lucas Corrêa
 */
public class ItensPedido {
    
    int codigoPedido;
    int codigoMercadoria;
    int qtdeProduto;
    double valorUniProduto;
    double valorTotProduto;

    public int getCodigoPedido() {
        return codigoPedido;
    }

    public void setCodigoPedido(int codigoPedido) {
        this.codigoPedido = codigoPedido;
    }

    public int getCodigoMercadoria() {
        return codigoMercadoria;
    }

    public void setCodigoMercadoria(int codigoMercadoria) {
        this.codigoMercadoria = codigoMercadoria;
    }

    public int getQtdeProduto() {
        return qtdeProduto;
    }

    public void setQtdeProduto(int qtdeProduto) {
        this.qtdeProduto = qtdeProduto;
    }

    public double getValorUniProduto() {
        return valorUniProduto;
    }

    public void setValorUniProduto(double valorUniProduto) {
        this.valorUniProduto = valorUniProduto;
    }

    public double getValorTotProduto() {
        return valorTotProduto;
    }

    public void setValorTotProduto(double valorTotProduto) {
        this.valorTotProduto = valorTotProduto;
    }
    
    
    
}
