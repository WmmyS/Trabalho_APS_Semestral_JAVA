/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Lucas Corrêa
 */
public class Mercadoria {
    
    int codMercadoria;
    String descMercadoria;
    String modeloMercadoria;
    int codCategoria;
    String necessidadeEstoque;
    int qtdeMercadoria;
    float precoaMercadoria;
    float precovMercadoria;
    int qtdeMinima;

    public int getQtdeMinima() {
        return qtdeMinima;
    }

    public void setQtdeMinima(int qtdeMinima) {
        this.qtdeMinima = qtdeMinima;
    }
    
    public int getCodMercadoria() {
        return codMercadoria;
    }

    public void setCodMercadoria(int codMercadoria) {
        this.codMercadoria = codMercadoria;
    }

    public String getDescMercadoria() {
        return descMercadoria;
    }

    public void setDescMercadoria(String descMercadoria) {
        this.descMercadoria = descMercadoria;
    }

    public String getModeloMercadoria() {
        return modeloMercadoria;
    }

    public void setModeloMercadoria(String modeloMercadoria) {
        this.modeloMercadoria = modeloMercadoria;
    }

    public int getCodCategoria() {
        return codCategoria;
    }

    public void setCodCategoria(int codCategoria) {
        this.codCategoria = codCategoria;
    }

    public String getNecessidadeEstoque() {
        return necessidadeEstoque;
    }

    public void setNecessidadeEstoque(String necessidadeEstoque) {
        this.necessidadeEstoque = necessidadeEstoque;
    }

    public int getQtdeMercadoria() {
        return qtdeMercadoria;
    }

    public void setQtdeMercadoria(int qtdeMercadoria) {
        this.qtdeMercadoria = qtdeMercadoria;
    }

    public float getPrecoaMercadoria() {
        return precoaMercadoria;
    }

    public void setPrecoaMercadoria(float precoaMercadoria) {
        this.precoaMercadoria = precoaMercadoria;
    }

    public float getPrecovMercadoria() {
        return precovMercadoria;
    }

    public void setPrecovMercadoria(float precovMercadoria) {
        this.precovMercadoria = precovMercadoria;
    }
    
    
}
