/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import banco_dados.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import classes.Categoria;
import java.sql.Connection;

/**
 *
 * @author Lucas Corrêa
 */
public class CategoriaDAO {
    
    private String sql;
    private PreparedStatement ps;
    
    public void inserirCategoria(Categoria categoria) throws SQLException{
        
        
        sql="insert into tb_categoria(desc_categoria) values (?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setString(1, categoria.getDescCategoria());
              
        ps.execute();
        
        ps.close();
    }
    
    public void alterarCategoria(Categoria categoria) throws SQLException{
        
        sql="update tb_categoria set desc_categoria = ? where cod_categoria = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        
        ps.setString(1, categoria.getDescCategoria());
        ps.setInt(2, categoria.getCodigoCategoria());     
              
        ps.execute();
        
        ps.close();
    }
    
    public void ExcluirCategoria(Categoria categoria) throws SQLException{
        
        sql="delete from tb_categoria where cod_categoria = ?";
        
        ps = Conexao.connection.prepareStatement(sql);

        ps.setInt(1, categoria.getCodigoCategoria());     
              
        ps.execute();
        
        ps.close();
    }
        
    
    public Categoria exibirCategoria(int codigo) throws SQLException{
        sql = "select * from tb_categoria where cod_categoria = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        

        Categoria categoria = new Categoria();
        if (rs.next()) {            
            categoria.setDescCategoria(rs.getString("desc_categoria"));
                 
        }
        else{
            JOptionPane.showMessageDialog(null, "Categoria não existe", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }

        return categoria;
        
    }
    
    public ArrayList<Categoria> listarCategoria(){
        
        Connection con = Conexao.Conectar();
        
        PreparedStatement stmt = null;
        ResultSet rs = null;

        //List<Produto> produtos = new ArrayList<>();
        ArrayList listaCategoria = new ArrayList();

        try {
            stmt = con.prepareStatement("select * from tb_categoria ORDER BY desc_categoria");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Categoria categoria = new Categoria();

                categoria.setCodigoCategoria(rs.getInt("cod_categoria"));
                categoria.setDescCategoria(rs.getString("desc_categoria"));
                listaCategoria.add(categoria);
            }

        } catch (SQLException ex) {
            System.out.println("Não há categorias");
        } 

        return listaCategoria;

    }
    
    
    public Integer listarUltimoCod() throws SQLException {
        Conexao c = new Conexao();
        String sql = "select cod_categoria from tb_categoria where cod_categoria = (SELECT MAX(cod_categoria) FROM tb_categoria)";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        int codigo = 0;
        

        if(rs.next()){
            codigo = rs.getInt("cod_categoria");    
        }
        


        return codigo + 1;
    }      
    
    /*
    public ArrayList<Fornecedor> listarTodosFornecedores() throws SQLException {
        Conexao c = new Conexao();
        String sql = "SELECT cod_fornecedor, nome_fornecedor, endereço_fornecedor, cnpj_fornecedor FROM tb_fornecedor ORDER BY nome_fornecedor";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        ArrayList listaFornecedores = new ArrayList();
        while (rs.next()) {
            Fornecedor fornecedor = new Fornecedor();
            fornecedor.setCodigoFornecedor(rs.getInt("cod_fornecedor"));
            fornecedor.setNomeFornecedor(rs.getString("nome_fornecedor"));
            fornecedor.setEnderecoFornecedor(rs.getString("endereço_fornecedor"));
            fornecedor.setCpfFornecedor(rs.getString("cnpj_fornecedor"));
            listaFornecedores.add(fornecedor);
        }

        return listaFornecedores;
    }
    
    
    public int RetornaCodigo(String recebeTexto) throws SQLException{
        sql = "select cod_categoria from tb_categoria where desc_categoria = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setString(1, recebeTexto);
        ResultSet rs = ps.executeQuery();
        

        int passaCodigo = 0;
        if (rs.next()) {            
            passaCodigo = rs.getInt("cod_categoria");
                 
        }


        return passaCodigo;        
        
    }
**/
    
    
}
