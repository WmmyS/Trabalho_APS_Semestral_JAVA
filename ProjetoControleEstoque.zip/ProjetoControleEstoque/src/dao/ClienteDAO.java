/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import classes.Cliente;
import banco_dados.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Lucas Corrêa
 */
public class ClienteDAO {
    
    private String sql;
    private PreparedStatement ps;
    
    public void inserirCliente(Cliente cliente) throws SQLException{
        
        sql="insert into tb_cliente(nome_cliente, tipo_cliente, email_cliente, apelido_cliente, endereço_cliente, bairro_cliente, cidade_cliente, estado_cliente, cep_cliente, telefone1_cliente, telefone2_cliente, data_nascimento_cliente, cpf_cliente, rg_cliente, cnpj_cliente, ie_cliente) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setString(1, cliente.getNomeCliente());
        ps.setInt(2, cliente.getTipoCliente());
        ps.setString(3, cliente.getEmailCliente());
        ps.setString(4, cliente.getApelidoCliente());
        ps.setString(5, cliente.getEnderecoCliente());
        ps.setString(6, cliente.getBairroCliente());
        ps.setString(7, cliente.getCidadeCliente());
        ps.setString(8, cliente.getEstadoCliente());
        ps.setString(9, cliente.getCepCliente());
        ps.setString(10, cliente.getTelefone1Cliente());
        ps.setString(11, cliente.getTelefone2Cliente());
        ps.setString(12, cliente.getDataNascimentoCliente());
        ps.setString(13, cliente.getCpfCliente());
        ps.setString(14, cliente.getRgCliente());
        ps.setString(15, cliente.getCnpjCliente());
        ps.setString(16, cliente.getIeCliente());
        
              
        ps.execute();
        
        ps.close();
    }
    
    public void alterarCliente(Cliente cliente) throws SQLException{
        
        sql="update tb_cliente set nome_cliente = ?, tipo_cliente = ?, email_cliente = ?, apelido_cliente = ?, endereço_cliente = ?, bairro_cliente = ?, cidade_cliente = ?, estado_cliente = ?, cep_cliente = ?, telefone1_cliente = ?, telefone2_cliente = ?, data_nascimento_cliente = ?, cpf_cliente = ?, rg_cliente = ?, cnpj_cliente = ?, ie_cliente = ? where cod_cliente = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        
        ps.setString(1, cliente.getNomeCliente());
        ps.setInt(2, cliente.getTipoCliente());
        ps.setString(3, cliente.getEmailCliente());
        ps.setString(4, cliente.getApelidoCliente());
        ps.setString(5, cliente.getEnderecoCliente());
        ps.setString(6, cliente.getBairroCliente());
        ps.setString(7, cliente.getCidadeCliente());
        ps.setString(8, cliente.getEstadoCliente());
        ps.setString(9, cliente.getCepCliente());
        ps.setString(10, cliente.getTelefone1Cliente());
        ps.setString(11, cliente.getTelefone2Cliente());
        ps.setString(12, cliente.getDataNascimentoCliente());
        ps.setString(13, cliente.getCpfCliente());
        ps.setString(14, cliente.getRgCliente());
        ps.setString(15, cliente.getCnpjCliente());
        ps.setString(16, cliente.getIeCliente());
        ps.setInt(17, cliente.getCodigoCliente());
        
              
        ps.execute();
        
        ps.close();
    }
    
    public void excluirCliente(Cliente cliente) throws SQLException{
        
        sql="delete from tb_cliente where cod_cliente = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, cliente.getCodigoCliente());        
              
        ps.execute();        
        ps.close();
    }
        
    
    
    
    
    
    public Cliente exibirCliente(int codigo) throws SQLException{
        sql = "select * from tb_cliente where cod_cliente = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        

        Cliente cliente = new Cliente();
        if (rs.next()) {
            cliente.setTipoCliente(rs.getInt("tipo_cliente"));
            cliente.setNomeCliente(rs.getString("nome_cliente"));
            cliente.setEmailCliente(rs.getString("email_cliente"));
            cliente.setApelidoCliente(rs.getString("apelido_cliente"));
            cliente.setEnderecoCliente(rs.getString("endereço_cliente"));
            cliente.setBairroCliente(rs.getString("bairro_cliente"));
            cliente.setCidadeCliente(rs.getString("cidade_cliente"));
            cliente.setEstadoCliente(rs.getString("estado_cliente"));
            cliente.setCepCliente(rs.getString("cep_cliente"));
            cliente.setTelefone1Cliente(rs.getString("telefone1_cliente"));
            cliente.setTelefone2Cliente(rs.getString("telefone2_cliente"));
            cliente.setDataNascimentoCliente(rs.getString("data_nascimento_cliente"));
            cliente.setCpfCliente(rs.getString("cpf_cliente"));
            cliente.setRgCliente(rs.getString("rg_cliente"));
            cliente.setCnpjCliente(rs.getString("cnpj_cliente"));
            cliente.setIeCliente(rs.getString("ie_cliente"));                       
        }
        else{
            JOptionPane.showMessageDialog(null, "Cliente não existe", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }

        return cliente;
        
    }
    
    public ArrayList<Cliente> listarTodosClientes() throws SQLException {
        Conexao c = new Conexao();
        String sql = "SELECT cod_cliente, nome_cliente, endereço_cliente, cpf_cliente FROM tb_cliente ORDER BY nome_cliente";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        ArrayList listaClientes = new ArrayList();
        while (rs.next()) {
            Cliente cliente = new Cliente();
            cliente.setCodigoCliente(rs.getInt("cod_cliente"));
            cliente.setNomeCliente(rs.getString("nome_cliente"));
            cliente.setEnderecoCliente(rs.getString("endereço_cliente"));
            cliente.setCpfCliente(rs.getString("cpf_cliente"));
            listaClientes.add(cliente);
        }

        return listaClientes;
    }
    
    public Integer listarUltimoCod() throws SQLException {
        Conexao c = new Conexao();
        String sql = "select cod_cliente from tb_cliente where cod_cliente = (SELECT MAX(cod_cliente) FROM tb_cliente)";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        int codigo = 0;
        

        if(rs.next()){
            codigo = rs.getInt("cod_cliente");    
        }
        


        return codigo + 1;
    }    
    

    
    
}
