/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import banco_dados.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import classes.Fornecedor;

/**
 *
 * @author Lucas Corrêa
 */
public class FornecedorDAO {
    
    private String sql;
    private PreparedStatement ps;
    
    public void inserirFornecedor(Fornecedor fornecedor) throws SQLException{
        
        
        sql="insert into tb_fornecedor(nome_fornecedor, tipo_fornecedor, email_fornecedor, apelido_fornecedor, endereço_fornecedor, bairro_fornecedor, cidade_fornecedor, estado_fornecedor, cep_fornecedor, telefone1_fornecedor, telefone2_fornecedor, data_nascimento_fornecedor, cnpj_fornecedor, ie_fornecedor) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setString(1, fornecedor.getNomeFornecedor());
        ps.setInt(2, fornecedor.getTipoFornecedor());
        ps.setString(3, fornecedor.getEmailFornecedor());
        ps.setString(4, fornecedor.getApelidoFornecedor());
        ps.setString(5, fornecedor.getEnderecoFornecedor());
        ps.setString(6, fornecedor.getBairroFornecedor());
        ps.setString(7, fornecedor.getCidadeFornecedor());
        ps.setString(8, fornecedor.getEstadoFornecedor());
        ps.setString(9, fornecedor.getCepFornecedor());
        ps.setString(10, fornecedor.getTelefone1Fornecedor());
        ps.setString(11, fornecedor.getTelefone2Fornecedor());
        ps.setString(12, fornecedor.getDataNascimentoFornecedor());
        ps.setString(13, fornecedor.getCnpjFornecedor());
        ps.setString(14, fornecedor.getIeFornecedor());
        
              
        ps.execute();
        
        ps.close();
    }
    
        public void alterarFornecedor(Fornecedor fornecedor) throws SQLException{
        
        sql="update tb_fornecedor set nome_fornecedor = ?, tipo_fornecedor = ?, email_fornecedor = ?, apelido_fornecedor = ?, endereço_fornecedor = ?, bairro_fornecedor = ?, cidade_fornecedor = ?, estado_fornecedor = ?, cep_fornecedor = ?, telefone1_fornecedor = ?, telefone2_fornecedor = ?, data_nascimento_fornecedor = ?, cnpj_fornecedor = ?, ie_fornecedor = ? where cod_fornecedor = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        
        ps.setString(1, fornecedor.getNomeFornecedor());
        ps.setInt(2, fornecedor.getTipoFornecedor());
        ps.setString(3, fornecedor.getEmailFornecedor());
        ps.setString(4, fornecedor.getApelidoFornecedor());
        ps.setString(5, fornecedor.getEnderecoFornecedor());
        ps.setString(6, fornecedor.getBairroFornecedor());
        ps.setString(7, fornecedor.getCidadeFornecedor());
        ps.setString(8, fornecedor.getEstadoFornecedor());
        ps.setString(9, fornecedor.getCepFornecedor());
        ps.setString(10, fornecedor.getTelefone1Fornecedor());
        ps.setString(11, fornecedor.getTelefone2Fornecedor());
        ps.setString(12, fornecedor.getDataNascimentoFornecedor());
        ps.setString(13, fornecedor.getCnpjFornecedor());
        ps.setString(14, fornecedor.getIeFornecedor());
        ps.setInt(15, fornecedor.getCodigoFornecedor());
        
              
            System.out.println(ps);
        
        ps.execute();
        
        ps.close();
    }
    
    
    public Fornecedor exibirFornecedor(int codigo) throws SQLException{
        sql = "select * from tb_fornecedor where cod_fornecedor = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        

        Fornecedor fornecedor = new Fornecedor();
        if (rs.next()) {
            fornecedor.setTipoFornecedor(rs.getInt("tipo_fornecedor"));
            fornecedor.setNomeFornecedor(rs.getString("nome_fornecedor"));
            fornecedor.setEmailFornecedor(rs.getString("email_fornecedor"));
            fornecedor.setApelidoFornecedor(rs.getString("apelido_fornecedor"));
            fornecedor.setEnderecoFornecedor(rs.getString("endereço_fornecedor"));
            fornecedor.setBairroFornecedor(rs.getString("bairro_fornecedor"));
            fornecedor.setCidadeFornecedor(rs.getString("cidade_fornecedor"));
            fornecedor.setEstadoFornecedor(rs.getString("estado_fornecedor"));
            fornecedor.setCepFornecedor(rs.getString("cep_fornecedor"));
            fornecedor.setTelefone1Fornecedor(rs.getString("telefone1_fornecedor"));
            fornecedor.setTelefone2Fornecedor(rs.getString("telefone2_fornecedor"));
            fornecedor.setDataNascimentoFornecedor(rs.getString("data_nascimento_fornecedor"));
            fornecedor.setCnpjFornecedor(rs.getString("cnpj_fornecedor"));
            fornecedor.setIeFornecedor(rs.getString("ie_fornecedor"));                       
        }
        else{
            JOptionPane.showMessageDialog(null, "Fornecedor não existe", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }

        return fornecedor;
        
    }
    
    public ArrayList<Fornecedor> listarTodosFornecedores() throws SQLException {
        Conexao c = new Conexao();
        String sql = "SELECT cod_fornecedor, nome_fornecedor, endereço_fornecedor, cnpj_fornecedor FROM tb_fornecedor ORDER BY nome_fornecedor";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        ArrayList listaFornecedores = new ArrayList();
        while (rs.next()) {
            Fornecedor fornecedor = new Fornecedor();
            fornecedor.setCodigoFornecedor(rs.getInt("cod_fornecedor"));
            fornecedor.setNomeFornecedor(rs.getString("nome_fornecedor"));
            fornecedor.setEnderecoFornecedor(rs.getString("endereço_fornecedor"));
            fornecedor.setCpfFornecedor(rs.getString("cnpj_fornecedor"));
            listaFornecedores.add(fornecedor);
        }

        return listaFornecedores;
    }
    
    public Integer listarUltimoCod() throws SQLException {
        Conexao c = new Conexao();
        String sql = "select cod_fornecedor from tb_fornecedor where cod_fornecedor = (SELECT MAX(cod_fornecedor) FROM tb_fornecedor)";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        int codigo = 0;
        

        if(rs.next()){
            codigo = rs.getInt("cod_fornecedor");    
        }
        


        return codigo + 1;
    }
    
    public void excluirFornecedor(Fornecedor fornecedor) throws SQLException{
        
        sql="delete from tb_fornecedor where cod_fornecedor = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, fornecedor.getCodigoFornecedor());        
              
        ps.execute();        
        ps.close();
    }

    
    
}
