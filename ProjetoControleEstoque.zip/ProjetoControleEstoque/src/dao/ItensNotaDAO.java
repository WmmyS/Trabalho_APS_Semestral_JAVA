/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import banco_dados.Conexao;
import classes.ItensNota;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Lucas Corrêa
 */
public class ItensNotaDAO {
    
    private String sql;
    private PreparedStatement ps;    
    
    public void inserirItens(ItensNota itens) throws SQLException{
        
        
        sql="insert into tb_itensnota(cod_nota, cod_fornecedor, cod_mercadoria, qtde_produto, valoraproduto, valorvproduto) values (?,?,?,?,?,?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, itens.getCodNota());
        ps.setInt(2, itens.getCodFornecedor());
        ps.setInt(3, itens.getCodMercadoria());
        ps.setInt(4, itens.getQtdeProduto());
        ps.setFloat(5, itens.getValorAp());
        ps.setFloat(6, itens.getValorVp());
              
        System.out.println(ps);
        ps.execute();
        
        ps.close();
    }
    
    public void alteraQtdeItens(int qtde, float valora, float valorv, int codNota, int codF, int codM) throws SQLException{
        
        
        sql="update tb_itensnota set qtde_produto = ?, valoraproduto = ?, valorvproduto = ? where cod_nota = ? and cod_fornecedor = ? and cod_mercadoria = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, qtde);        
        ps.setFloat(2, valora);
        ps.setFloat(3, valorv);
        ps.setInt(4, codNota);
        ps.setInt(5, codF);
        ps.setInt(6, codM);
        
        

              
        ps.execute();
        
        ps.close();
    }
    
    public void removeItem(ItensNota itens) throws SQLException{
        
        sql = "delete from tb_itensnota where cod_nota = ? and cod_fornecedor = ? and cod_mercadoria = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, itens.getCodNota());
        ps.setInt(2, itens.getCodFornecedor());
        ps.setInt(3, itens.getCodMercadoria());
        
        ps.execute();
        
        ps.close();
        
    }
    
    
        
    
}
