/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import banco_dados.Conexao;
import classes.ItensPedido;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Lucas Corrêa
 */
public class ItensPedidoDAO {
    
    private String sql;
    private PreparedStatement ps;    
    
        public void inserirItens(ItensPedido itens) throws SQLException{
        
        
        sql="insert into tb_itenspedido(cod_pedido, cod_mercadoria, qtde_produto, valoruproduto, valortproduto) values (?,?,?,?,?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, itens.getCodigoPedido());
        ps.setInt(2, itens.getCodigoMercadoria());
        ps.setInt(3, itens.getQtdeProduto());
        ps.setDouble(4, itens.getValorUniProduto());
        ps.setDouble(5, itens.getValorTotProduto());
        
        ps.execute();
        
        ps.close();
    }
        
    public void alteraQtdeItens(int qtde, float valoru, float valort, int codPedido, int codM) throws SQLException{
        
        
        sql="update tb_itenspedido set qtde_produto = ?, valoruproduto = ?, valorTproduto = ? where cod_pedido = ? and cod_mercadoria = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, qtde);
        ps.setFloat(2, valoru);
        ps.setFloat(3, valort);
        ps.setInt(4, codPedido);
        ps.setInt(5, codM);
        
        

              
        ps.execute();
        
        ps.close();
    }    

    public void removeItem(ItensPedido itens) throws SQLException{
        
        sql = "delete from tb_itenspedido where cod_pedido = ? and cod_mercadoria = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, itens.getCodigoPedido());
        ps.setInt(2, itens.getCodigoMercadoria());
        
        ps.execute();
        
        ps.close();
        
    }    
    
}
