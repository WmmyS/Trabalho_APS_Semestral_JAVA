/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import banco_dados.Conexao;
import classes.Mercadoria;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lucas Corrêa
 */
public class MercadoriaDAO {
    
    private String sql;
    private PreparedStatement ps;
    
    public void inserirMercadoria(Mercadoria mercadoria) throws SQLException{
        
        
        sql="insert into tb_mercadoria(desc_mercadoria, modelo_mercadoria, cod_categoria, neces_estoque, qtde_mercadoria, precoa_mercadoria, precov_mercadoria, qtde_min) values (?,?,?,?,?,?,?,?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setString(1, mercadoria.getDescMercadoria());
        ps.setString(2, mercadoria.getModeloMercadoria());
        ps.setInt(3, mercadoria.getCodCategoria());
        ps.setString(4, mercadoria.getNecessidadeEstoque());
        ps.setInt(5, mercadoria.getQtdeMercadoria());
        ps.setFloat(6, mercadoria.getPrecoaMercadoria());
        ps.setFloat(7, mercadoria.getPrecovMercadoria());
        ps.setInt(8, mercadoria.getQtdeMinima());
        
              
        ps.execute();
        
        ps.close();
    }
    
    public void alterarMercadoria(String desc, String modelo, int codC, String neces,  float precoa, float precov, int qtdemin, int codM) throws SQLException{
        
        sql="update tb_mercadoria set desc_mercadoria = ?, modelo_mercadoria = ?, cod_categoria = ?, neces_estoque = ?, precoa_mercadoria = ?, precov_mercadoria = ?, qtde_min = ? where cod_mercadoria = ?";
        
        ps = Conexao.connection.prepareStatement(sql);       
        
        ps.setString(1, desc);
        ps.setString(2, modelo);
        ps.setInt(3, codC);
        ps.setString(4, neces);
        ps.setFloat(5, precoa);
        ps.setFloat(6, precov);
        ps.setInt(7, qtdemin);
        ps.setInt(8, codM);
        
              
        ps.execute();
        
        ps.close();
    }
    
    
    
    public void alterarMercadoriaEntrada(int qtde, int cod) throws SQLException{
        
           
        
        PreparedStatement pss;
        
        String sqll="select qtde_mercadoria, precoa_mercadoria, precov_mercadoria from tb_mercadoria where cod_mercadoria = ?";
        pss = Conexao.connection.prepareStatement(sqll);     
        pss.setInt(1, cod);
        ResultSet rss = pss.executeQuery();
        
        if(rss.next()){
            
            sql="update tb_mercadoria set qtde_mercadoria = ? where cod_mercadoria = ?";
        
            ps = Conexao.connection.prepareStatement(sql);
            
            int qtdee = rss.getInt("qtde_mercadoria");
            ps.setInt(1,  qtdee + qtde);
            ps.setInt(2, cod);


            ps.execute();

            ps.close();            
            
        }        

    }    
    
    public void alterarMercadoriaEntrada(int qtde, float valora, float valorv, int cod) throws SQLException{
        
                 
        PreparedStatement pss;
        
        String sqll="select qtde_mercadoria, precoa_mercadoria, precov_mercadoria from tb_mercadoria where cod_mercadoria = ?";
        pss = Conexao.connection.prepareStatement(sqll);     
        pss.setInt(1, cod);
        ResultSet rss = pss.executeQuery();
        
        if(rss.next()){
            
            sql="update tb_mercadoria set qtde_mercadoria = ?, precoa_mercadoria = ?, precov_mercadoria = ? where cod_mercadoria = ?";
        
            ps = Conexao.connection.prepareStatement(sql);
            
            int qtdee = rss.getInt("qtde_mercadoria");
            ps.setInt(1,  qtdee + qtde);
            ps.setFloat(2, valora);
            ps.setFloat(3, valorv);
            ps.setInt(4, cod);


            ps.execute();

            ps.close();            
            
        }        

    }     
    
    public void alterarMercadoriaAtEntrada(int qtde, int cod) throws SQLException{
        
            
            sql="update tb_mercadoria set qtde_mercadoria = ? where cod_mercadoria = ?";
        
            ps = Conexao.connection.prepareStatement(sql);
            
           
            ps.setInt(1,  qtde);
            ps.setInt(2, cod);


            ps.execute();

            ps.close();            
            
                   
        

    }     
    
    public void ExcluirMercadoria(int cod) throws SQLException{        
            
            sql="delete from tb_mercadoria where cod_mercadoria = ?";
        
            ps = Conexao.connection.prepareStatement(sql);  
            
            
           
            ps.setInt(1,  cod);

            System.out.println(ps);
            ps.execute();

            ps.close();            
            
                   
        

    }     
    
    
    public Integer mostraQtdeMercadoria(int cod) throws SQLException {
        sql = "select qtde_mercadoria from tb_mercadoria where cod_mercadoria = ?";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, cod);
        ResultSet rs = ps.executeQuery();

        int qtde = 0;
        

        if(rs.next()){
            qtde = rs.getInt("qtde_mercadoria");    
        }
        


        return qtde;
    }      
    
    public Mercadoria mostraQtdeMercadoria() throws SQLException {
        sql = "select * from tb_mercadoria where qtde_mercadoria < qtde_min";
        
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        
        ResultSet rs = ps.executeQuery();

        int qtde = 0;
        
        Mercadoria mercadoria = new Mercadoria();
        while(rs.next()){
            
            mercadoria.setDescMercadoria(rs.getString("desc_mercadoria"));
            mercadoria.setModeloMercadoria(rs.getString("modelo_mercadoria"));
            mercadoria.setCodCategoria(rs.getInt("cod_categoria"));
            mercadoria.setNecessidadeEstoque(rs.getString("neces_estoque"));
            mercadoria.setQtdeMercadoria(rs.getInt("qtde_mercadoria"));
            mercadoria.setPrecoaMercadoria(rs.getFloat("precoa_mercadoria"));
            mercadoria.setPrecovMercadoria(rs.getFloat("precov_mercadoria"));  
        }
        


        return mercadoria;
    } 
    
    
    public Mercadoria exibirMercadoria(int codigo) throws SQLException{
        sql = "select * from tb_mercadoria where cod_mercadoria = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        

        Mercadoria mercadoria = new Mercadoria();
        if (rs.next()) {
            
            mercadoria.setDescMercadoria(rs.getString("desc_mercadoria"));
            mercadoria.setModeloMercadoria(rs.getString("modelo_mercadoria"));
            mercadoria.setCodCategoria(rs.getInt("cod_categoria"));
            mercadoria.setNecessidadeEstoque(rs.getString("neces_estoque"));
            mercadoria.setQtdeMercadoria(rs.getInt("qtde_mercadoria"));
            mercadoria.setPrecoaMercadoria(rs.getFloat("precoa_mercadoria"));
            mercadoria.setPrecovMercadoria(rs.getFloat("precov_mercadoria"));
            mercadoria.setQtdeMinima(rs.getInt("qtde_min"));

        }
        else{
            JOptionPane.showMessageDialog(null, "Mercadoria não existe", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }

        return mercadoria;
        
    }
    
    public Integer listarUltimoCod() throws SQLException {
        Conexao c = new Conexao();
        String sql = "select cod_mercadoria from tb_mercadoria where cod_mercadoria = (SELECT MAX(cod_mercadoria) FROM tb_mercadoria)";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        int codigo = 0;
        

        if(rs.next()){
            codigo = rs.getInt("cod_mercadoria");    
        }
        


        return codigo + 1;
    }        
        
    
}
