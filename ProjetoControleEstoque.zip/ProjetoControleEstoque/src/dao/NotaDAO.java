/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import banco_dados.Conexao;
import classes.Nota;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lucas Corrêa
 */
public class NotaDAO {
    
    private String sql;
    private PreparedStatement ps;    
    
    public void inserirNota(Nota nota) throws SQLException{
        
        
        sql="insert into tb_notaentrada(cod_nota, cod_fornecedor, data_nota) values (?,?,?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, nota.getCodigoNota());
        ps.setInt(2, nota.getCodigoFornecedor());
        ps.setDate(3, nota.getDataNota());
              
        ps.execute();
        
        ps.close();
    }
    
    public void alteraNota(Nota nota, int codN, int codF) throws SQLException{
        
        
        sql="update tb_notaentrada set cod_nota = ?, cod_fornecedor = ? where cod_nota = ? and cod_fornecedor = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, nota.getCodigoNota());
        ps.setInt(2, nota.getCodigoFornecedor());
        ps.setInt(3, codN);
        ps.setInt(4, codF);
              
        ps.execute();
        
        ps.close();
    } 
    
    public void excluiNota(Nota nota) throws SQLException{
        
        
        sql="delete from tb_notaentrada where cod_nota = ? and cod_fornecedor = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, nota.getCodigoNota());
        ps.setInt(2, nota.getCodigoFornecedor());
              
        ps.execute();
        
        ps.close();
    }    
    
    public Nota exibirNota(int codigoN, int codigoF) throws SQLException{
        sql = "select * from tb_notaentrada where cod_nota = ? and cod_fornecedor = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, codigoN);
        ps.setInt(2, codigoF);
        ResultSet rs = ps.executeQuery();
        

        Nota nota = new Nota();
        if (rs.next()) {
            nota.setCodigoNota(codigoN);
            nota.setDataNota(rs.getDate("data_nota"));
            
        }
        else{
            JOptionPane.showMessageDialog(null, "Nota não existe", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }

        return nota;
        
    }    
    
    public boolean comparaNrNota(int codigoNota, int codigoFornecedor) throws SQLException{
        sql = "select * from tb_notaentrada where cod_nota = ? and cod_fornecedor = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, codigoNota);
        ps.setInt(2, codigoFornecedor);
        ResultSet rs = ps.executeQuery();
        
        boolean passa = false;

        
        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "Nota já existe", "Atenção!", JOptionPane.ERROR_MESSAGE); 
            passa = true;            
        }

        return passa;

        
    }  
    
    public double valorNota(String sql) throws SQLException{
        this.sql = sql;
        
        ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        System.out.println(ps);
        
        double valor = 0;
        
        if(rs.next()){
            valor = rs.getDouble("valor_total");
        }

        return valor;
        
    } 
    
}
