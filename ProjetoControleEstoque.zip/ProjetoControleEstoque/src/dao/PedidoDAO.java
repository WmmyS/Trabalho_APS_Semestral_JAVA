/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import banco_dados.Conexao;
import classes.Pedido;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lucas Corrêa
 */
public class PedidoDAO {
    
    
    private String sql;
    private PreparedStatement ps;    
    
    public void inserirPedido(Pedido pedido) throws SQLException{
        
        
        sql="insert into tb_pedido(cod_cliente, data_pedido, valor_pedido) values (?,?,?)";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, pedido.getCodigoCliente());
        ps.setDate(2, pedido.getDataPedido());
        ps.setFloat(3, pedido.getValorPedido());
              
        ps.execute();
        
        ps.close();
    }    
    
    public void alteraPedido(Pedido pedido) throws SQLException{
        
        sql="update tb_pedido set cod_cliente = ?, valor_pedido = ? where cod_pedido = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, pedido.getCodigoCliente());
        ps.setFloat(2, pedido.getValorPedido());
        ps.setInt(3, pedido.getCodigoPedido());
              
        ps.execute();
        
        ps.close();        
        
    }
    
    public Pedido exibirPedido(int codigo) throws SQLException{
        sql = "select * from tb_pedido where cod_pedido = ?";
        ps = Conexao.connection.prepareStatement(sql);
        ps.setInt(1, codigo);
        ResultSet rs = ps.executeQuery();
        

        Pedido pedido = new Pedido();
        if (rs.next()) {
            pedido.setCodigoCliente(rs.getInt("cod_cliente"));
            pedido.setDataPedido(rs.getDate("data_pedido"));
            pedido.setValorPedido(rs.getFloat("valor_pedido"));
            
        }
        else{
            JOptionPane.showMessageDialog(null, "Pedido não existe", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }

        return pedido;
        
    }     
    
    public Integer listarUltimoCod() throws SQLException {
        Conexao c = new Conexao();
        String sql = "select cod_pedido from tb_pedido where cod_pedido = (SELECT MAX(cod_pedido) FROM tb_pedido)";
        PreparedStatement ps = Conexao.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        int codigo = 0;
        

        if(rs.next()){
            codigo = rs.getInt("cod_pedido");    
        }
        


        return codigo + 1;
    }    
    
    public void excluiPedido(int cod) throws SQLException{
        
        sql="delete from tb_pedido where cod_pedido = ?";
        
        ps = Conexao.connection.prepareStatement(sql);
        
        ps.setInt(1, cod);
              
        ps.execute();
        
        ps.close();        
        
    }
    
}
