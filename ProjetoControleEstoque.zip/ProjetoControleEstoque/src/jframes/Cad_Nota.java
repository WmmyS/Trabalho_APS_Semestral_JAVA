/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframes;

import banco_dados.Conexao;
import classes.Fornecedor;
import classes.ItensNota;
import classes.Mercadoria;
import classes.ModeloTabela;
import classes.Nota;
import com.sun.glass.ui.Window.Level;
import dao.FornecedorDAO;
import dao.ItensNotaDAO;
import dao.MercadoriaDAO;
import dao.NotaDAO;
import imagens.Icone;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Logger;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



/**
 *
 * @author Lucas Corrêa
 */
public class Cad_Nota extends javax.swing.JFrame {


    
    Date hoje = new Date();
    SimpleDateFormat df;
    
     int removeLinha ;
    
    Conexao conecta;
    
    public static String passaNomeF = null;
    public static String passaDescricaoF = null;
    public static Boolean cadPedido;
    public static boolean gained = false;
    public static boolean gainedF = false;
    public static boolean gainedP = false;
    int codigoNota = 0;
    int codigoFornecedor = 0;
    int contaClickTabela = 0;
    int linhaEsq = -1;
    
    
    /**
     * Creates new form Cad_Cliente
     */
    
    DefaultTableModel tp;
    DefaultTableModel TabelaObter; 
    
    
    private boolean inteiro(double num) {
	int aux = (int)num;
	
	return (((double)aux) == num);
    }
    

    
    public void mostra(int cod){
        jLabel1.setText(String.valueOf(cod));
        
    }
    
    public void LimpaItem(){
        txtCodItemm.setText("");
        txtDescItemm.setText("");
        txtVA.setText("");
        txtQtdeItemm.setText("");
        txtVV.setText("");
        txtCodItemm.setEditable(true);
        txtDescItemm.setEditable(true);
        txtVA.setEditable(true);    
    }
    
    public void Fornecedor(){
        if(!txtCodFornecedor.getText().equals("")){
            
            try{
                Integer.parseInt(txtCodFornecedor.getText());

                Fornecedor fornecedor = new Fornecedor();
                FornecedorDAO forncedorDao = new FornecedorDAO();
            
                try {
                    fornecedor = forncedorDao.exibirFornecedor(Integer.parseInt(txtCodFornecedor.getText()));
                    
                    if(fornecedor.getNomeFornecedor() != null){
                        txtNomeFornecedor.setText(fornecedor.getNomeFornecedor());
                        txtCNPJ.setText(fornecedor.getCnpjFornecedor());
                        txtCodFornecedor.setEditable(false);
                        txtNomeFornecedor.setEditable(false);
                        txtCNPJ.setEditable(false);   
                    }
                    else{
                        txtCodFornecedor.requestFocus();
                        txtCodFornecedor.setText("");
                        
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    txtCodFornecedor.requestFocus();
                    txtCodFornecedor.setText("");


                }

            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Digite um número inteiro para o fornecedor");
                txtCodFornecedor.requestFocus();
                txtCodFornecedor.setText("");
            }
            
        }
    }
    
    public void LimpaFornecedor(){
        txtNomeFornecedor.setText("");
        txtCodFornecedor.setText("");
        txtCNPJ.setText("");
        txtCodFornecedor.setEditable(true);
        txtNomeFornecedor.setEditable(true);
        txtCNPJ.setEditable(true);
    }
    
    public void LimpaCampos(){
        LimpaFornecedor();
        LimpaItem();
        df = new SimpleDateFormat("dd/MM/yyyy");
        txtData.setText(df.format(hoje));
        txtSubtotal.setText("");
        btnLimpaFornecedor.setEnabled(true);
        txtCodNota.setText("");
        btnAltera.setText("Editar");
       
              
    }
    
    public void EditableTrue(){
        txtCodFornecedor.setEditable(true);
        txtNomeFornecedor.setEditable(true);
        txtCNPJ.setEditable(true);
        txtCodItemm.setEditable(true);
        txtDescItemm.setEditable(true);
        txtVA.setEditable(true); 
        TabProdutos.setEnabled(true);
        txtQtdeItemm.setEditable(true);
        txtCodNota.setEditable(true);
        txtVV.setEditable(true);
    }
    
    public void EditableFalse(){
        txtCodFornecedor.setEditable(false);
        txtNomeFornecedor.setEditable(false);
        txtCNPJ.setEditable(false);
        txtCodItemm.setEditable(false);
        txtDescItemm.setEditable(false);
        txtVA.setEditable(false);  
        TabProdutos.setEnabled(false);
        txtQtdeItemm.setEditable(false);
        txtVV.setEditable(false);
        
    }    
    
    ArrayList recebeDadosTabela = new ArrayList();
    
    public void consultaTabela(String SQL){

        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código", "Descrição", "Quantidade", "Valor Atacado", "Valor Varejo"};
        
        DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
        DefaultTableModel TabelaObter = (DefaultTableModel) TabProdutos1.getModel(); 
        
        

        conecta.executaSQL(SQL);
        
        try{
            conecta.rs.first();
            do{
                tp.addRow(new Object[]{conecta.rs.getInt("cod_mercadoria"),conecta.rs.getString("desc_mercadoria"), conecta.rs.getInt("qtde_produto"), conecta.rs.getDouble("valoraproduto"), conecta.rs.getDouble("valorvproduto")});
                TabelaObter.addRow(new Object[]{conecta.rs.getInt("cod_mercadoria"),conecta.rs.getString("desc_mercadoria"), conecta.rs.getInt("qtde_produto"), conecta.rs.getDouble("valoraproduto"), conecta.rs.getDouble("valorvproduto")});
                recebeDadosTabela.add(new Object[]{conecta.rs.getInt("cod_mercadoria"), conecta.rs.getInt("qtde_produto"), conecta.rs.getDouble("valoraproduto"), conecta.rs.getDouble("valorvproduto")});
            }while (conecta.rs.next());
                    
        }catch(SQLException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(null, "Produtos não encontrados", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }
        
   
     
        
        
        
    }    
    

    JMenuItem jMenuItemRemover = new JMenuItem();

  
    
    public void limpaTabela(){
        DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
        tp.setNumRows(0);
        
        DefaultTableModel tp1 = (DefaultTableModel) TabProdutos1.getModel();
        tp1.setNumRows(0);        
    }
    
    public Cad_Nota() {
        initComponents();
        
        conecta = new Conexao();
        //conexao.Conectar();
        gained = false;
        gainedF = false;
        gainedP = false;
        
        df = new SimpleDateFormat("dd/MM/yyyy");
        txtData.setText(df.format(hoje));
        
        Icone icone = new Icone();
        this.setIconImage(icone.getIconTitulo());        

        txtCodNota.requestFocus();
        btnAltera.setEnabled(false);
        btnExcluir.setEnabled(false);
        
        TabProdutos1.setVisible(false);

        EditableFalse();
        txtCodFornecedor.setEditable(true);
        txtNomeFornecedor.setEditable(true);
        
        jMenuItemRemover.setText("Remover Item");
        
        jPopupMenu1.add(jMenuItemRemover);
        
        
        jMenuItemRemover.addActionListener(new java.awt.event.ActionListener() {
              // Importe a classe java.awt.event.ActionEvent
            public void actionPerformed(ActionEvent e) {                 
                DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
                tp.removeRow(linhaEsq);
            }
        });  
        
        
        
  
        
        
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        grupoPessoa = new javax.swing.ButtonGroup();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtNomeFornecedor = new javax.swing.JTextField();
        txtCNPJ = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtCodFornecedor = new javax.swing.JTextField();
        btnLimpaFornecedor = new javax.swing.JButton();
        btnObter = new javax.swing.JButton();
        btnAltera = new javax.swing.JButton();
        btnIncluir = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txtData = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtCodNota = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabProdutos = new javax.swing.JTable();
        txtSubtotal = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtDescItemm = new javax.swing.JTextField();
        txtVA = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtCodItemm = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtVV = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        txtQtdeItemm = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabProdutos1 = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Notas de Entrada");
        addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                formFocusGained(evt);
            }
        });
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Informações do Forncedor"));
        jPanel1.setToolTipText("");

        jLabel1.setText("Nome:");

        txtNomeFornecedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtNomeFornecedorFocusLost(evt);
            }
        });
        txtNomeFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeFornecedorActionPerformed(evt);
            }
        });

        txtCNPJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCNPJActionPerformed(evt);
            }
        });

        jLabel5.setText("CNPJ");

        jLabel12.setText("Código:");

        txtCodFornecedor.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtCodFornecedorAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtCodFornecedor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCodFornecedorFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCodFornecedorFocusLost(evt);
            }
        });
        txtCodFornecedor.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtCodFornecedorInputMethodTextChanged(evt);
            }
        });
        txtCodFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodFornecedorActionPerformed(evt);
            }
        });

        btnLimpaFornecedor.setText("Limpar Fonecedor");
        btnLimpaFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpaFornecedorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(txtCodFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtNomeFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtCNPJ, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnLimpaFornecedor, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNomeFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtCodFornecedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtCNPJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(btnLimpaFornecedor)
                .addContainerGap())
        );

        btnObter.setText("Obter");
        btnObter.setMaximumSize(new java.awt.Dimension(72, 23));
        btnObter.setMinimumSize(new java.awt.Dimension(72, 23));
        btnObter.setPreferredSize(new java.awt.Dimension(120, 120));
        btnObter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnObterActionPerformed(evt);
            }
        });

        btnAltera.setText("Editar");
        btnAltera.setMaximumSize(new java.awt.Dimension(72, 23));
        btnAltera.setMinimumSize(new java.awt.Dimension(72, 23));
        btnAltera.setPreferredSize(new java.awt.Dimension(120, 120));
        btnAltera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlteraActionPerformed(evt);
            }
        });

        btnIncluir.setText("Novo");
        btnIncluir.setMaximumSize(new java.awt.Dimension(72, 23));
        btnIncluir.setMinimumSize(new java.awt.Dimension(72, 23));
        btnIncluir.setPreferredSize(new java.awt.Dimension(120, 120));
        btnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIncluirActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.setMaximumSize(new java.awt.Dimension(72, 23));
        btnExcluir.setMinimumSize(new java.awt.Dimension(72, 23));
        btnExcluir.setPreferredSize(new java.awt.Dimension(120, 120));
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnLimpar.setText("Limpar");
        btnLimpar.setMaximumSize(new java.awt.Dimension(72, 23));
        btnLimpar.setMinimumSize(new java.awt.Dimension(72, 23));
        btnLimpar.setPreferredSize(new java.awt.Dimension(120, 120));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Informações da Nota"));
        jPanel2.setToolTipText("");

        txtData.setEditable(false);
        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        jLabel6.setText("Data:");

        jLabel13.setText("Número da Nota:");

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, txtCodFornecedor, org.jdesktop.beansbinding.ObjectProperty.create(), txtCodNota, org.jdesktop.beansbinding.BeanProperty.create("nextFocusableComponent"));
        bindingGroup.addBinding(binding);

        txtCodNota.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtCodNotaAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtCodNota.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCodNotaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCodNotaFocusLost(evt);
            }
        });
        txtCodNota.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtCodNotaInputMethodTextChanged(evt);
            }
        });
        txtCodNota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodNotaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCodNota, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtCodNota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TabProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição", "Quantidade", "Valor Atacado", "Valor Varejo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabProdutos.getTableHeader().setReorderingAllowed(false);
        TabProdutos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabProdutosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabProdutos);

        txtSubtotal.setEditable(false);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Item"));
        jPanel4.setToolTipText("");

        jLabel7.setText("Descrição: ");

        txtDescItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDescItemmFocusLost(evt);
            }
        });
        txtDescItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescItemmActionPerformed(evt);
            }
        });

        txtVA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtVAActionPerformed(evt);
            }
        });

        jLabel10.setText("Valor Atacado:");

        jLabel15.setText("Código:");

        txtCodItemm.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtCodItemmAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtCodItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCodItemmFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCodItemmFocusLost(evt);
            }
        });
        txtCodItemm.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtCodItemmInputMethodTextChanged(evt);
            }
        });
        txtCodItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodItemmActionPerformed(evt);
            }
        });

        jLabel17.setText("Valor Varejo:");

        txtVV.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtVVAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtVV.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtVVFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtVVFocusLost(evt);
            }
        });
        txtVV.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtVVInputMethodTextChanged(evt);
            }
        });
        txtVV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtVVActionPerformed(evt);
            }
        });

        jButton6.setText("Adicionar Item");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Limpar Item");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        txtQtdeItemm.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtQtdeItemmAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtQtdeItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtQtdeItemmFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtQtdeItemmFocusLost(evt);
            }
        });
        txtQtdeItemm.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtQtdeItemmInputMethodTextChanged(evt);
            }
        });
        txtQtdeItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQtdeItemmActionPerformed(evt);
            }
        });

        jLabel16.setText("Quantidade:");

        jButton8.setText("Cadastrar Item");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(33, 33, 33)
                        .addComponent(txtCodItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtVA, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDescItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtQtdeItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtVV, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(txtDescItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel16)
                        .addComponent(txtQtdeItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel15)
                        .addComponent(txtCodItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel17)
                        .addComponent(txtVV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(txtVA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton6)
                        .addComponent(jButton7)
                        .addComponent(jButton8))))
        );

        TabProdutos1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição", "Quantidade", "Valor Atacado", "Valor Varejo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabProdutos1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabProdutos1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TabProdutos1);

        jMenu1.setText("Consulta");

        jMenuItem1.setText("Notas");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnObter, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(btnAltera, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAltera, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnObter, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        bindingGroup.bind();

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeFornecedorActionPerformed

    private void txtCNPJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCNPJActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCNPJActionPerformed

    private void txtCodFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodFornecedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodFornecedorActionPerformed

    private void btnObterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnObterActionPerformed
    

    codigoNota = 0;
    codigoFornecedor = 0;        
        if(txtCodNota.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Informe um código", "Atenção", JOptionPane.ERROR_MESSAGE);        
            txtCodNota.requestFocus();
        } 
        else if(txtCodFornecedor.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Informe um código", "Atenção", JOptionPane.ERROR_MESSAGE);        
            txtCodFornecedor.requestFocus();
        }
        else{
            try{
                Integer.parseInt(txtCodNota.getText());
                try{
                    Integer.parseInt(txtCodFornecedor.getText());
                    Nota nota = new Nota();
                    try{
                        
                        NotaDAO notaDao = new NotaDAO();
                        nota = notaDao.exibirNota(Integer.parseInt(txtCodNota.getText()), Integer.parseInt(txtCodFornecedor.getText()));      
                    }catch(SQLException ex){
                        txtCodNota.setText("");
                        txtCodNota.requestFocus();
                        txtCodFornecedor.setText("");
                    } 
                    

                    if(nota.getCodigoNota() != 0){
                        //txtCodFornecedor.setText(String.valueOf(nota.getCodigoFornecedor()));
                        btnAltera.setEnabled(true);
                        btnExcluir.setEnabled(true);
                        btnIncluir.setEnabled(false);
                        btnObter.setEnabled(false);



                        EditableFalse();
                        
                        Fornecedor fornecedor = new Fornecedor();
                        FornecedorDAO fornecedorDao = new FornecedorDAO();

                        try {
                            fornecedor = fornecedorDao.exibirFornecedor(Integer.parseInt(txtCodFornecedor.getText()));
                            txtNomeFornecedor.setText(fornecedor.getNomeFornecedor());

                        } catch (SQLException ex) {
                            Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                        }
                        if(!txtNomeFornecedor.getText().equals("")){
                            txtCNPJ.setText(fornecedor.getCnpjFornecedor());
                            txtCodFornecedor.setEditable(false);
                            txtNomeFornecedor.setEditable(false);
                            txtCNPJ.setEditable(false);

                        }                   


                        consultaTabela("select tb_itensNota.cod_mercadoria, tb_mercadoria.desc_mercadoria, tb_itensNota.qtde_produto, tb_itensNota.valoraproduto, tb_itensNota.valorvproduto from tb_itensnota INNER JOIN tb_mercadoria on tb_itensnota.cod_mercadoria = tb_mercadoria.cod_mercadoria where cod_nota = "+Integer.parseInt(txtCodNota.getText())+ "and cod_fornecedor = "+Integer.parseInt(txtCodFornecedor.getText()));

                        txtData.setEditable(true);

                        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");

                        txtData.setText(df.format(nota.getDataNota()));
                        txtData.setEditable(false);

                        DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();



                        int contador = TabProdutos.getRowCount();
                        double valortotal = 0;



                        for (int i = 0 ; i < contador;  i++){           
                           valortotal += Double.parseDouble(tp.getValueAt(i, 3).toString()) * Integer.parseInt(tp.getValueAt(i, 2).toString());
                        }
                        txtSubtotal.setText(String.valueOf(valortotal));   

                        codigoNota = Integer.parseInt(txtCodNota.getText());
                        codigoFornecedor = Integer.parseInt(txtCodFornecedor.getText());
                        TabelaObter = (DefaultTableModel) TabProdutos.getModel();

                    }
                    else{
                        limpaTabela();
                        LimpaCampos();
                        txtCodNota.requestFocus();
                    }


                }catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(this, "Insira um número inteiro no código do fornecedor");
                    txtCodFornecedor.setText("");
                    txtCodFornecedor.requestFocus();
                }
            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Insira um número inteiro no código da nota");
                txtCodNota.requestFocus();
                txtCodNota.setText("");
            }
        }

    }//GEN-LAST:event_btnObterActionPerformed

    private void btnAlteraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlteraActionPerformed

        if(btnAltera.getText().equals("Editar")){
            btnAltera.setText("Alterar");
            EditableTrue();
        }
        else{
            int conta = TabProdutos.getRowCount();
            int codigoTb1 = 0;
            int codigoTb2 = 0;

            if(txtCodNota.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Informe um código", "Atenção", JOptionPane.ERROR_MESSAGE);        
                txtCodNota.requestFocus();
            } 
            else if(txtCodFornecedor.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Informe o Fornecedor", "Atenção", JOptionPane.ERROR_MESSAGE);        
                txtCodFornecedor.requestFocus();
            }   
            else if(conta == 0){
                JOptionPane.showMessageDialog(null, "Adicione ao menos um produto", "Atenção", JOptionPane.ERROR_MESSAGE); 
                txtCodItemm.requestFocus();
            }
            else if(!txtCodItemm.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Termine de Adicionar o produto", "Atenção", JOptionPane.ERROR_MESSAGE); 
            }
            else{

                Nota nota = new Nota();
                NotaDAO notaDao = new NotaDAO();
                MercadoriaDAO mercadoriaDao = new MercadoriaDAO();

                nota.setCodigoNota(Integer.parseInt(txtCodNota.getText()));
                nota.setCodigoFornecedor(Integer.parseInt(txtCodFornecedor.getText()));




                try{
                    notaDao.alteraNota(nota, codigoNota, codigoFornecedor);
                    JOptionPane.showMessageDialog(null, "Nota "+txtCodNota.getText()+" Alterada com sucesso", "Cadastro de Notas", JOptionPane.INFORMATION_MESSAGE);

                    }catch(SQLException ex){       
                            JOptionPane.showMessageDialog(null, "Não foi possível alterar nota "+ex, "Cadastro de Notas", JOptionPane.ERROR_MESSAGE);           

                }  

                DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
                int contador = tp.getRowCount();

                if(contador > 0){


                    TabelaObter = (DefaultTableModel) TabProdutos1.getModel();

                    int contadorrr = 0;


                    int contadorr = TabelaObter.getRowCount();

                    System.out.println(contadorr);


                    for (int i = 0; i < contador; i++) {        

                        for (int a = 0; a < contadorr; a++) {

                            codigoTb1 = Integer.parseInt(tp.getValueAt(i, 0).toString());
                            codigoTb2 = Integer.parseInt(TabelaObter.getValueAt(a, 0).toString());
                            if(codigoTb1 == codigoTb2){
                                System.out.println(TabelaObter.getValueAt(a, 1).toString());
                                System.out.println(tp.getValueAt(i, 1).toString());

                                    int tabela = 0;
                                    tabela = Integer.parseInt(tp.getValueAt(i, 2).toString());
                                    int tabelaObter = 0;
                                    tabelaObter = Integer.parseInt(TabelaObter.getValueAt(a, 2).toString());
                                    int qtdeAtualizacao = 0;

                                    System.out.println(tp.getValueAt(i, 1).toString()+"qtde tabela"+tabela);
                                    System.out.println("qtde tabela obter "+tabelaObter);

                                    int recebeQtde = 0;




                                    qtdeAtualizacao = tabela - tabelaObter; 
                                    System.out.println(qtdeAtualizacao);

                                    qtdeAtualizacao +=  tabelaObter;     


                                    int codigoAtualizacao = Integer.parseInt(tp.getValueAt(i, 0).toString());

                                    try {
                                        mercadoriaDao.alterarMercadoriaEntrada(tabela - tabelaObter, Float.parseFloat(tp.getValueAt(i, 3).toString()), Float.parseFloat(tp.getValueAt(i, 4).toString()), codigoAtualizacao);


                                    } catch (SQLException e) {
                                        System.out.println("AQUI?"+e);
                                    }






                                    ItensNotaDAO itensNotaDAO = new ItensNotaDAO();

                                    System.out.println(Float.parseFloat(tp.getValueAt(i, 3).toString()));

                                    try{
                                        itensNotaDAO.alteraQtdeItens(qtdeAtualizacao, Float.parseFloat(tp.getValueAt(i, 3).toString()), Float.parseFloat(tp.getValueAt(i, 4).toString()), Integer.parseInt(txtCodNota.getText()), Integer.parseInt(txtCodFornecedor.getText()), codigoAtualizacao);
                                    }catch(SQLException p){                                    
                                        System.out.println("b"+p);
                                    }





                            }
                        }   
                    }


                    contador = tp.getRowCount();	
                    contadorr = TabelaObter.getRowCount();



                        for(int b = 0; b < contadorr; b++){
                            contadorrr = 0;
                            for(int c = 0; c < contador; c++){
                                if(!TabelaObter.getValueAt(b, 0).toString().equals(tp.getValueAt(c, 0).toString())){
                                    contadorrr += 1;
                                    if(contadorrr == contador){
                                        System.out.println("qq"+contadorrr);

                                        int codigoP = Integer.parseInt(TabelaObter.getValueAt(b, 0).toString());
                                        int qtdeMenos =  0;

                                        ItensNota itensNota = new ItensNota();
                                        ItensNotaDAO itensNotaDAO = new ItensNotaDAO();

                                        itensNota.setCodNota(nota.getCodigoNota());
                                        itensNota.setCodMercadoria(codigoP);
                                        itensNota.setCodFornecedor(nota.getCodigoFornecedor());


                                        try{
                                            itensNotaDAO.removeItem(itensNota);
                                            mercadoriaDao.alterarMercadoriaEntrada(-Integer.parseInt(TabelaObter.getValueAt(b, 2).toString()), codigoP);
                                        }catch(SQLException ex){
                                            System.out.println("a"+ex);
                                        }

                                        //qtdeMenos -= Integer.parseInt(TabelaObter.getValueAt(b, 2).toString());
                                        //System.out.println(codigoP + " "+TabelaObter.getValueAt(b, 1).toString()+" " +qtdeMenos);
                                        contadorrr = 0;

                                    }

                                }         
                            }

                        }

                    if(contador > contadorr){
                        for(int b = 0; b < contador; b++){
                            contadorrr = 0;
                            for(int c = 0; c < contadorr; c++){
                                if(!tp.getValueAt(b, 0).toString().equals(TabelaObter.getValueAt(c, 0).toString())){
                                    contadorrr += 1;
                                    if(contadorrr == contadorr){
                                        System.out.println("qq"+contadorrr);

                                        int codigoP = Integer.parseInt(tp.getValueAt(b, 0).toString());
                                        int qtdeMenos =  0;

                                        ItensNota itensNota = new ItensNota();
                                        ItensNotaDAO itensNotaDAO = new ItensNotaDAO();

                                        itensNota.setCodNota(nota.getCodigoNota());
                                        itensNota.setCodMercadoria(codigoP);
                                        itensNota.setCodFornecedor(nota.getCodigoFornecedor());
                                        itensNota.setQtdeProduto(Integer.parseInt(tp.getValueAt(b, 2).toString()));
                                        itensNota.setValorAp(Float.parseFloat(tp.getValueAt(b, 3).toString()));
                                        itensNota.setValorVp(Float.parseFloat(tp.getValueAt(b, 4).toString()));                


                                        try{
                                            itensNotaDAO.inserirItens(itensNota);
                                            mercadoriaDao.alterarMercadoriaEntrada(Integer.parseInt(tp.getValueAt(b, 2).toString()), codigoP);
                                            System.out.println("");
                                        }catch(SQLException ex){
                                            System.out.println("a"+ex);
                                        }

                                        //qtdeMenos -= Integer.parseInt(TabelaObter.getValueAt(b, 2).toString());
                                        //System.out.println(codigoP + " "+TabelaObter.getValueAt(b, 1).toString()+" " +qtdeMenos);
                                        contadorrr = 0;

                                    }

                                }         
                            }

                        }        


                    }
                }            




                /**    
                ItensNotaDAO itensDao = new ItensNotaDAO();

                for (int i = 0 ; i < contador;  i++){
                    ItensNota itensNota = new ItensNota();


                    itensNota.setCodNota(Integer.parseInt(txtCodNota.getText()));
                    itensNota.setCodFornecedor(Integer.parseInt(txtCodFornecedor.getText()));
                    itensNota.setCodMercadoria(Integer.parseInt(tp.getValueAt(i, 0).toString()));
                    itensNota.setQtdeProduto(Integer.parseInt(tp.getValueAt(i, 2).toString()));
                    itensNota.setValorAp(Float.parseFloat(tp.getValueAt(i, 3).toString()));
                    itensNota.setValorVp(Float.parseFloat(tp.getValueAt(i, 4).toString()));


                    try{
                        itensDao.alteraNotaItens(itensNota);
                        //mercadoriaDao.alterarMercadoriaEntrada(Integer.parseInt(tp.getValueAt(i, 2).toString()), Integer.parseInt(tp.getValueAt(i, 0).toString()));

                    }catch(SQLException ex){        
                            System.out.println(ex);


                    }  



                }
                * */
            LimpaCampos();
            limpaTabela();
            btnAltera.setText("Editar");
            btnAltera.setEnabled(false);
            btnExcluir.setEnabled(false);
            btnLimpar.doClick();
            }        
        }
    }//GEN-LAST:event_btnAlteraActionPerformed

    private void btnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIncluirActionPerformed
        if(btnIncluir.getText().equals("Novo")){
            if(txtCodNota.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Informe o código da nota", "Atenção", JOptionPane.ERROR_MESSAGE);        
                txtCodNota.requestFocus();
            } 
            else if(txtCodFornecedor.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Informe o código do fornecedor", "Atenção", JOptionPane.ERROR_MESSAGE);        
                txtCodFornecedor.requestFocus();
            }
            else if(txtNomeFornecedor.getText().equals("")){
                txtCodFornecedor.requestFocus();
                txtCodFornecedor.setText("");
            }            
            else{
                boolean teste = false;
                NotaDAO notaDAO = new NotaDAO();
                try {
                    teste = notaDAO.comparaNrNota(Integer.parseInt(txtCodNota.getText()), Integer.parseInt(txtCodFornecedor.getText()));
                } catch (Exception e) {
                }                
                if(teste == false){
                    btnIncluir.setText("Incluir");
                    EditableTrue();
                    btnObter.setEnabled(false);
                }
            }
        }
        else{
            
            DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
            int contador = TabProdutos.getRowCount();

            if(txtCodNota.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Informe um código", "Atenção", JOptionPane.ERROR_MESSAGE);        
                txtCodNota.requestFocus();
            } 
            else if(txtCodFornecedor.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Informe o Fornecedor", "Atenção", JOptionPane.ERROR_MESSAGE);        
                txtCodFornecedor.requestFocus();
            }   
            else if(contador == 0){
                JOptionPane.showMessageDialog(null, "Adicione ao menos um produto", "Atenção", JOptionPane.ERROR_MESSAGE); 
                txtCodItemm.requestFocus();
            }
            else{

                Nota nota = new Nota();
                NotaDAO notaDao = new NotaDAO();
                MercadoriaDAO mercadoriaDao = new MercadoriaDAO();

                nota.setCodigoNota(Integer.parseInt(txtCodNota.getText()));
                nota.setCodigoFornecedor(Integer.parseInt(txtCodFornecedor.getText()));

                Date dataUtil = hoje;
                java.sql.Date dataSql = null;

                dataUtil = new java.sql.Date(dataUtil.getTime());
                dataSql = (java.sql.Date) dataUtil;



                nota.setDataNota(dataSql);
                tp = (DefaultTableModel) TabProdutos.getModel();
                contador = tp.getRowCount();



                try{
                    notaDao.inserirNota(nota);
                    JOptionPane.showMessageDialog(null, "Nota "+txtCodNota.getText()+" Cadastrada com sucesso", "Cadastro de Notas", JOptionPane.INFORMATION_MESSAGE);

                }catch(SQLException ex){       
                        JOptionPane.showMessageDialog(null, "Não foi possível cadastrar nota "+ex, "Cadastro de Notas", JOptionPane.ERROR_MESSAGE);           

                }              




                ItensNotaDAO itensDao = new ItensNotaDAO();

                for (int i = 0 ; i < contador;  i++){
                    ItensNota itensNota = new ItensNota();


                    itensNota.setCodNota(Integer.parseInt(txtCodNota.getText()));
                    itensNota.setCodFornecedor(Integer.parseInt(txtCodFornecedor.getText()));
                    itensNota.setCodMercadoria(Integer.parseInt(tp.getValueAt(i, 0).toString()));
                    itensNota.setQtdeProduto(Integer.parseInt(tp.getValueAt(i, 2).toString()));
                    itensNota.setValorAp(Float.parseFloat(tp.getValueAt(i, 3).toString()));
                    itensNota.setValorVp(Float.parseFloat(tp.getValueAt(i, 4).toString()));


                    try{
                        itensDao.inserirItens(itensNota);
                        mercadoriaDao.alterarMercadoriaEntrada(Integer.parseInt(tp.getValueAt(i, 2).toString()), Float.parseFloat(tp.getValueAt(i, 3).toString()), Float.parseFloat(tp.getValueAt(i, 4).toString()), Integer.parseInt(tp.getValueAt(i, 0).toString()));
                        
                    }catch(SQLException ex){        
                            System.out.println(ex);


                    }  



                
                }
            btnIncluir.setText("Novo");
            
            LimpaCampos();
            limpaTabela();
            btnObter.setEnabled(true);

            }
        }
        
        
    }//GEN-LAST:event_btnIncluirActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed

    try{
        Integer.parseInt(txtCodNota.getText());
        try{
            Integer.parseInt(txtCodFornecedor.getText());
        
            DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
            int contador = tp.getRowCount();

            if(contador > 0){

                int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir essa nota de entrada?", "ATENÇÃO", JOptionPane.YES_NO_OPTION);


                if(resposta == 0){
                    for(int i = 0; i < contador; i++){
                        ItensNota itensNota = new ItensNota();
                        ItensNotaDAO itensNotaDAO = new ItensNotaDAO();
                        MercadoriaDAO mercadoriaDAO = new MercadoriaDAO();

                        itensNota.setCodNota(Integer.parseInt(txtCodNota.getText()));
                        itensNota.setCodFornecedor(Integer.parseInt(txtCodFornecedor.getText()));
                        itensNota.setCodMercadoria(Integer.parseInt(TabelaObter.getValueAt(i, 0).toString()));
                        try{
                            itensNotaDAO.removeItem(itensNota);
                            mercadoriaDAO.alterarMercadoriaEntrada(-Integer.parseInt(TabelaObter.getValueAt(i, 2).toString()), Integer.parseInt(TabelaObter.getValueAt(i, 0).toString()));
                        }catch(SQLException ex){
                            System.out.println("a"+ex);
                        }            

                    }
                    try {
                        Nota nota = new Nota();
                        NotaDAO notaDAO = new NotaDAO();

                        nota.setCodigoNota(Integer.parseInt(txtCodNota.getText()));
                        nota.setCodigoFornecedor(Integer.parseInt(txtCodFornecedor.getText()));     

                        notaDAO.excluiNota(nota);

                        JOptionPane.showMessageDialog(this, "Nota excluída com sucesso!");
                    } catch (SQLException e) {

                        System.out.println(e);
                    }
                    LimpaCampos();
                    limpaTabela();
                    btnExcluir.setEnabled(false);
                    btnAltera.setEnabled(false);
                    btnLimpar.doClick();

                }
            }
        }catch(NumberFormatException ex){
        JOptionPane.showMessageDialog(this, "Insira um número inteiro no código do fornecedor");
        txtCodFornecedor.setText("");
        txtCodFornecedor.requestFocus();
                }
    }catch(NumberFormatException ex){
        JOptionPane.showMessageDialog(this, "Insira um número inteiro no código da nota");
        txtCodNota.requestFocus();
        txtCodNota.setText("");
    }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        LimpaCampos();
        limpaTabela();
        btnIncluir.setEnabled(true);
        btnObter.setEnabled(true);
        EditableFalse();
        btnExcluir.setEnabled(false);
        btnAltera.setEnabled(false);
        txtCodFornecedor.setEditable(true);
        txtNomeFornecedor.setEditable(true);
        btnIncluir.setText("Novo");
    }//GEN-LAST:event_btnLimparActionPerformed

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus
        if(gained == true){  
            gained = false;
            ConsultaNotas consultaNotas = new ConsultaNotas();
            if(consultaNotas.passaCodigoNota >= 0 && consultaNotas.passaCodigoFornecedor >= 0){            
                txtCodNota.setText(String.valueOf(consultaNotas.passaCodigoNota));
                txtCodFornecedor.setText(String.valueOf(consultaNotas.passaCodigoFornecedor));
                btnObter.doClick();
            }
            
        }
        else if(gainedF == true){
            gainedF = false;
            if(passaNomeF != null){
                try{
                    Integer.parseInt(passaNomeF);

                    txtCodFornecedor.setText(passaNomeF);
                    passaNomeF = "";

                    Fornecedor fornecedor = new Fornecedor();
                    FornecedorDAO forncedorDao = new FornecedorDAO();



                    try {
                        fornecedor = forncedorDao.exibirFornecedor(Integer.parseInt(txtCodFornecedor.getText()));
                        txtNomeFornecedor.setText(fornecedor.getNomeFornecedor());

                    } catch (SQLException ex) {
                        Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                    if(!txtNomeFornecedor.getText().equals("")){
                        txtCNPJ.setText(fornecedor.getCnpjFornecedor());
                        txtCodFornecedor.setEditable(false);
                        txtNomeFornecedor.setEditable(false);
                        txtCNPJ.setEditable(false);

                    }            
                }catch(NumberFormatException ex){
                    System.out.println(ex);
                    
                }
            }
        }
        else if(gainedP == true){
            gainedP = false;
            if(passaDescricaoF != null){
                try{
                    Integer.parseInt(passaDescricaoF);

                    txtCodItemm.setText(passaDescricaoF);
                    passaDescricaoF = "";

                    Mercadoria produto = new Mercadoria();
                    MercadoriaDAO produtoDao = new MercadoriaDAO();



                    try {
                        produto = produtoDao.exibirMercadoria(Integer.parseInt(txtCodItemm.getText()));
                        txtDescItemm.setText(produto.getDescMercadoria());
                        txtQtdeItemm.requestFocus();
                    } catch (SQLException ex) {
                        Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                    if(!txtDescItemm.getText().equals("")){
                        txtVA.setText(String.valueOf(produto.getPrecoaMercadoria()));
                        txtVV.setText(String.valueOf(produto.getPrecovMercadoria()));
                        txtCodItemm.setEditable(false);
                        txtDescItemm.setEditable(false);


                    }            
                }catch(NumberFormatException ex){
                    System.out.println(ex);
                    
                }
            }        

        }
        
     
       
    }//GEN-LAST:event_formWindowGainedFocus

    private void formFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_formFocusGained
        
        
    }//GEN-LAST:event_formFocusGained

    private void txtCodFornecedorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodFornecedorFocusLost
        Fornecedor();
    }//GEN-LAST:event_txtCodFornecedorFocusLost

    private void txtCodFornecedorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodFornecedorFocusGained

    }//GEN-LAST:event_txtCodFornecedorFocusGained

    private void txtCodFornecedorInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtCodFornecedorInputMethodTextChanged

    }//GEN-LAST:event_txtCodFornecedorInputMethodTextChanged

    private void txtCodFornecedorAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtCodFornecedorAncestorAdded
        /**
        if(!txtCod.getText().equals("")){
            btnIncluir.setEnabled(false);
            txtCod.setEnabled(false);

            Cliente recebeCliente = new Cliente();
            try {
                recebeCliente = clienteDao.exibirCliente(Integer.parseInt(txtCod.getText()));
            } catch (SQLException ex) {
                Logger.getLogger(Cad_Cliente.class.getName()).log(Level.SEVERE, null, ex);
                txtCod.setEnabled(true);

            }
            txtNome.setText(recebeCliente.getNomeCliente());
            txtEmail.setText(recebeCliente.getEmailCliente());
            txtApelido.setText(recebeCliente.getApelidoCliente());
            txtEndereco.setText(recebeCliente.getEnderecoCliente());
            txtBairro.setText(recebeCliente.getBairroCliente());
            txtCidade.setText(recebeCliente.getCidadeCliente());
            cboEstado.setSelectedItem(recebeCliente.getEstadoCliente());
            txtCEP.setText(recebeCliente.getCepCliente());
            txtTelefone1.setText(recebeCliente.getTelefone1Cliente());
            txtTelefone2.setText(recebeCliente.getTelefone2Cliente());
            txtData.setText(recebeCliente.getDataNascimentoCliente());
            txtCPF.setText(String.valueOf(recebeCliente.getCpfCliente()));
            txtRG.setText(String.valueOf(recebeCliente.getRgCliente()));
            txtCNPJ.setText(String.valueOf(recebeCliente.getCnpjCliente()));
            txtIE.setText(String.valueOf(recebeCliente.getIeCliente()));
        }
        * */
    }//GEN-LAST:event_txtCodFornecedorAncestorAdded

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
       
    }//GEN-LAST:event_formWindowClosed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        ConsultaNotas consultaNotas = new ConsultaNotas();
        consultaNotas.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void txtCodNotaAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtCodNotaAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodNotaAncestorAdded

    private void txtCodNotaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodNotaFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodNotaFocusGained

    private void txtCodNotaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodNotaFocusLost
        /**
        if(!txtCodNota.getText().equals("")){
            NotaDAO notaDao = new NotaDAO();
            try{
                notaDao.comparaNrNota(Integer.parseInt(txtCodNota.getText()));                 
            }catch(SQLException e){
                System.out.println(e);
            }                        
        }

        **/
    }//GEN-LAST:event_txtCodNotaFocusLost

    private void txtCodNotaInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtCodNotaInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodNotaInputMethodTextChanged

    private void txtCodNotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodNotaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodNotaActionPerformed

    private void txtDescItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescItemmActionPerformed

    private void txtVAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtVAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVAActionPerformed

    private void txtCodItemmAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtCodItemmAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmAncestorAdded

    private void txtCodItemmFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodItemmFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmFocusGained

    private void txtCodItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodItemmFocusLost
        if(!txtCodItemm.getText().equals("")){
            
            try{
                Integer.parseInt(txtCodItemm.getText());

                Mercadoria item = new Mercadoria();
                MercadoriaDAO mercadoriaDao = new MercadoriaDAO();
            
                try {
                    item = mercadoriaDao.exibirMercadoria(Integer.parseInt(txtCodItemm.getText()));
                    
                    if(item.getDescMercadoria() != null){
                        txtDescItemm.setText(item.getDescMercadoria());                                            
                        txtQtdeItemm.requestFocus();
                        txtVA.setText(String.valueOf(item.getPrecoaMercadoria()));
                        txtVV.setText(String.valueOf(item.getPrecovMercadoria()));
                        txtCodItemm.setEditable(false);
                        txtDescItemm.setEditable(false);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Digite um número inteiro para o código do produto");
                txtCodItemm.requestFocus();
                txtCodItemm.setText("");
            }
            
        }
    }//GEN-LAST:event_txtCodItemmFocusLost

    private void txtCodItemmInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtCodItemmInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmInputMethodTextChanged

    private void txtCodItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmActionPerformed

    private void txtQtdeItemmAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtQtdeItemmAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmAncestorAdded

    private void txtQtdeItemmFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQtdeItemmFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmFocusGained

    private void txtQtdeItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQtdeItemmFocusLost

    }//GEN-LAST:event_txtQtdeItemmFocusLost

    private void txtQtdeItemmInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtQtdeItemmInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmInputMethodTextChanged

    private void txtQtdeItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQtdeItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmActionPerformed

    private void txtVVAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtVVAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVVAncestorAdded

    private void txtVVFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtVVFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVVFocusGained

    private void txtVVFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtVVFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVVFocusLost

    private void txtVVInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtVVInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVVInputMethodTextChanged

    private void txtVVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtVVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVVActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        if(txtCodItemm.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Digite um produto para adicionar!");
        }
        else if(txtQtdeItemm.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Informe a quantidade!", "Atenção!", JOptionPane.INFORMATION_MESSAGE);
        }
        else{

            boolean produtoIgual = false;
            double valortotal = 0;

            DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
            int contador = tp.getRowCount();


            for (int i = 0 ; i < contador;  i++){

                if(txtCodItemm.getText().equals(tp.getValueAt(i, 0).toString())){
                    produtoIgual = true;
                    JOptionPane.showMessageDialog(null, "Produto já adicionado!", "Atenção!", JOptionPane.OK_OPTION);
                    LimpaItem();


            }

            }

            if(produtoIgual == false){
                tp.addRow(new Object[]{String.valueOf(txtCodItemm.getText()), String.valueOf(txtDescItemm.getText()),  String.valueOf(txtQtdeItemm.getText()), String.valueOf(txtVA.getText()), String.valueOf(txtVV.getText())});        

            }

           contador = TabProdutos.getRowCount();      



           for (int i = 0 ; i < contador;  i++){           
              valortotal += Double.parseDouble(tp.getValueAt(i, 3).toString()) * Integer.parseInt(tp.getValueAt(i, 2).toString());
           }
           txtSubtotal.setText(String.valueOf(valortotal));
           
           txtCodItemm.setEditable(true);
           txtDescItemm.setEditable(true);

           LimpaItem();
       }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void btnLimpaFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpaFornecedorActionPerformed
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente limpar os campos do fornecedor?", "Atenção!", JOptionPane.YES_NO_OPTION);
        
        if(resposta == 0){        
            LimpaFornecedor();
        }

        
    }//GEN-LAST:event_btnLimpaFornecedorActionPerformed

    private void txtNomeFornecedorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNomeFornecedorFocusLost

        if(txtCodFornecedor.getText().equals("") && !txtNomeFornecedor.getText().equals("")){
            ConsultaFornecedor consultaFornecedor = new ConsultaFornecedor();
            consultaFornecedor.setVisible(true);           
            passaNomeF = txtNomeFornecedor.getText();
            
        }
    }//GEN-LAST:event_txtNomeFornecedorFocusLost

    private void txtDescItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDescItemmFocusLost
        if(txtCodItemm.getText().equals("") && !txtDescItemm.getText().equals("")){
            ConsultaMercadoria consultaMercadoria = new ConsultaMercadoria();
            consultaMercadoria.setVisible(true);           
            passaDescricaoF = txtDescItemm.getText();
            
        }
    }//GEN-LAST:event_txtDescItemmFocusLost

    private void TabProdutosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabProdutosMouseClicked
        removeLinha = TabProdutos.getSelectedRow();         
        contaClickTabela += 1;  
        
        linhaEsq = TabProdutos.rowAtPoint(evt.getPoint());
        
        if (evt.getButton() == evt.BUTTON3 && TabProdutos.isEnabled()) { // Clique com botao direito do mouse.             
            jPopupMenu1.show(TabProdutos, evt.getX(), evt.getY());
        }
        
        if (evt.getClickCount() == 2 && TabProdutos.isEnabled()) {   
            
            contaClickTabela -= 1;           
            if(txtCodItemm.getText().equals("")){            
                DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();

                int linha = TabProdutos.getSelectedRow();     

                txtCodItemm.setText(TabProdutos.getValueAt(linha, 0).toString());
                txtDescItemm.setText(TabProdutos.getValueAt(linha, 1).toString());
                txtQtdeItemm.setText(TabProdutos.getValueAt(linha, 2).toString());
                txtVA.setText(TabProdutos.getValueAt(linha, 3).toString());
                txtVV.setText(TabProdutos.getValueAt(linha, 4).toString());

                txtQtdeItemm.requestFocus();
                txtCodItemm.setEditable(false);
                txtDescItemm.setEditable(false);                           

                tp.removeRow(linha);
            }

        }
    }//GEN-LAST:event_TabProdutosMouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        LimpaItem();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void TabProdutos1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabProdutos1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_TabProdutos1MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        Cad_Mercadoria cad_Mercadoria = new Cad_Mercadoria();
        cad_Mercadoria.setVisible(true);
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cad_Nota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cad_Nota().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TabProdutos;
    private javax.swing.JTable TabProdutos1;
    private javax.swing.JButton btnAltera;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnIncluir;
    private javax.swing.JButton btnLimpaFornecedor;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnObter;
    private javax.swing.ButtonGroup grupoPessoa;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtCNPJ;
    protected javax.swing.JTextField txtCodFornecedor;
    protected javax.swing.JTextField txtCodItemm;
    protected javax.swing.JTextField txtCodNota;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtDescItemm;
    private javax.swing.JTextField txtNomeFornecedor;
    protected javax.swing.JTextField txtQtdeItemm;
    private javax.swing.JTextField txtSubtotal;
    private javax.swing.JTextField txtVA;
    protected javax.swing.JTextField txtVV;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
