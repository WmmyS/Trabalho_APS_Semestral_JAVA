/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframes;

import banco_dados.Conexao;
import classes.Cliente;
import classes.ItensNota;
import classes.ItensPedido;
import classes.Mercadoria;
import classes.Pedido;
import com.sun.glass.ui.Window.Level;
import dao.ClienteDAO;
import dao.ItensPedidoDAO;
import dao.MercadoriaDAO;
import dao.PedidoDAO;
import imagens.Icone;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Logger;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.io.FileOutputStream;
import java.util.Date;
 

import java.text.SimpleDateFormat;



/**
 *
 * @author Lucas Corrêa
 */
public class Cad_Pedido extends javax.swing.JFrame {


    
    
    
    Date hoje = new Date();
    SimpleDateFormat df;
    int linhaEsq = -1;
    int linha = -1;
    Conexao conecta;
    
    public static String passaNome = null;
    public static String passaDescricao = null;
    public static Boolean cadPedido;
    public static Boolean gained = false;
    public static boolean gainedCPP = false;
    public static boolean pedido = false;
    public static boolean gainedInfomation = false;
    

    
    DefaultTableModel tp;
    DefaultTableModel TabelaObter;     
    
    /**
     * Creates new form Cad_Cliente
     */
    
    boolean primeiroItem = true;
    int pegaQtdeTab = 0;
    boolean obter = false;
    
    private boolean inteiro(double num) {
	int aux = (int)num;
	
	return (((double)aux) == num);
    }
    

    
    public void mostra(int cod){
        jLabel1.setText(String.valueOf(cod));
        
    }
    
    public void CamposEditT(){
        
        txtDescItemm.setEditable(true);
        txtValorItemm.setEditable(true);
        txtQtdeItemm.setEditable(true);
        txtVTItemm.setEditable(true);
        txtCodCliente.setEditable(true);
        txtNomeCliente.setEditable(true);
        txtCPF.setEditable(true);
        txtCodItemm.setEditable(true);
        btnLimpaCliente.setEnabled(true);
        btnAddItem.setEnabled(true);
        TabProdutos.setEnabled(true);
        
    }
    
    public void CamposEditF(){
        
        txtDescItemm.setEditable(false);
        txtValorItemm.setEditable(false);
        txtQtdeItemm.setEditable(false);
        txtVTItemm.setEditable(false);
        txtCodCliente.setEditable(false);
        txtNomeCliente.setEditable(false);
        txtCPF.setEditable(false);
        txtCodItemm.setEditable(false);
        btnLimpaCliente.setEnabled(false);
        btnAddItem.setEnabled(false);
        TabProdutos.setEnabled(false);
        
    }    
    
    public void LimpaItem(){
        txtCodItemm.setText("");
        txtDescItemm.setText("");
        txtValorItemm.setText("");
        txtQtdeItemm.setText("");
        txtVTItemm.setText("");
        txtCodItemm.setEditable(true);
        txtDescItemm.setEditable(true);
        txtValorItemm.setEditable(true);    
    }
    
    public void LimpaCliente(){
        txtNomeCliente.setText("");
        txtCodCliente.setText("");
        txtCPF.setText("");
        txtCodCliente.setEditable(true);
        txtNomeCliente.setEditable(true);
        txtCPF.setEditable(true);
    }
    
    public void LimpaCampos(){
        LimpaCliente();
        LimpaItem();
        txtSubtotal.setText("");
        txtCod1.setText("");
        txtCod1.setEnabled(true);
        btnObter.setEnabled(true);   
        df = new SimpleDateFormat("dd/MM/yyyy");
        txtData.setText(df.format(hoje));
        btnIncluir.setEnabled(true);
        btnExcluir.setEnabled(false);
        btnAlterar.setEnabled(false);
        CamposEditF();
        btnIncluir.setText("Novo");
       
              
    }
    
   
    
    
    
    public void LimpaTabela(){
        DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
        DefaultTableModel tp1 = (DefaultTableModel) TabProdutos1.getModel();
        tp1.setNumRows(0);
        tp.setNumRows(0);
    }
    
   public void consultaTabela(String SQL){

        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código", "Descrição", "Quantidade", "Valor Atacado", "Valor Varejo"};
        
        DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
        DefaultTableModel TabelaObter = (DefaultTableModel) TabProdutos1.getModel(); 
        
        

        conecta.executaSQL(SQL);
        
        try{
            conecta.rs.first();
            do{
                tp.addRow(new Object[]{conecta.rs.getInt("cod_mercadoria"),conecta.rs.getString("desc_mercadoria"), conecta.rs.getInt("qtde_produto"), conecta.rs.getDouble("valoruproduto"), conecta.rs.getDouble("valortproduto")});
                TabelaObter.addRow(new Object[]{conecta.rs.getInt("cod_mercadoria"),conecta.rs.getString("desc_mercadoria"), conecta.rs.getInt("qtde_produto"), conecta.rs.getDouble("valoruproduto"), conecta.rs.getDouble("valortproduto")});
                
            }while (conecta.rs.next());
                    
        }catch(SQLException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(null, "Produtos não encontrados", "Atenção!", JOptionPane.ERROR_MESSAGE);
        }
        
   
     
        
        
        
    }    
   
   JMenuItem jMenuItemRemover = new JMenuItem();
    
    public Cad_Pedido() {
        initComponents();
        
      
        //conexao.Conectar();
        
        df = new SimpleDateFormat("dd/MM/yyyy");
        txtData.setText(df.format(hoje));
        

        txtCod1.requestFocus();
        
        Icone icone = new Icone();
        this.setIconImage(icone.getIconTitulo());        
        
        conecta = new Conexao();
        this.setBackground(Color.white);

        CamposEditF();
        
        gainedCPP = false;
        gainedInfomation = false;
        gained = false; 
        
        
        
        jMenuItemRemover.setText("Remover Item");
        
        jPopupMenu1.add(jMenuItemRemover);
        
        
        jMenuItemRemover.addActionListener(new java.awt.event.ActionListener() {
              // Importe a classe java.awt.event.ActionEvent
            public void actionPerformed(ActionEvent e) {                 
                DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
                tp.removeRow(linhaEsq);
            }
        });  
        
        btnExcluir.setEnabled(false);
        btnAlterar.setEnabled(false);
        
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupoPessoa = new javax.swing.ButtonGroup();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtNomeCliente = new javax.swing.JTextField();
        txtCPF = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtCodCliente = new javax.swing.JTextField();
        btnLimpaCliente = new javax.swing.JButton();
        btnObter = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnIncluir = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txtData = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtCod1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabProdutos = new javax.swing.JTable();
        txtSubtotal = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtDescItemm = new javax.swing.JTextField();
        txtValorItemm = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtCodItemm = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtQtdeItemm = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtVTItemm = new javax.swing.JTextField();
        btnAddItem = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabProdutos1 = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Pedido");
        addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                formFocusGained(evt);
            }
        });
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Informações do Cliente"));
        jPanel1.setToolTipText("");

        jLabel1.setText("Nome:");

        txtNomeCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtNomeClienteFocusLost(evt);
            }
        });
        txtNomeCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeClienteActionPerformed(evt);
            }
        });

        txtCPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCPFActionPerformed(evt);
            }
        });

        jLabel5.setText("CPF:");

        jLabel12.setText("Código:");

        txtCodCliente.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtCodClienteAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtCodCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCodClienteFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCodClienteFocusLost(evt);
            }
        });
        txtCodCliente.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtCodClienteInputMethodTextChanged(evt);
            }
        });
        txtCodCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodClienteActionPerformed(evt);
            }
        });

        btnLimpaCliente.setText("Limpar Cliente");
        btnLimpaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpaClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(33, 33, 33)
                        .addComponent(txtCodCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCPF, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimpaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtCodCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(btnLimpaCliente)
                .addContainerGap())
        );

        btnObter.setText("Obter");
        btnObter.setMaximumSize(new java.awt.Dimension(72, 23));
        btnObter.setMinimumSize(new java.awt.Dimension(72, 23));
        btnObter.setPreferredSize(new java.awt.Dimension(120, 120));
        btnObter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnObterActionPerformed(evt);
            }
        });

        btnAlterar.setText("Editar");
        btnAlterar.setMaximumSize(new java.awt.Dimension(72, 23));
        btnAlterar.setMinimumSize(new java.awt.Dimension(72, 23));
        btnAlterar.setPreferredSize(new java.awt.Dimension(120, 120));
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        btnIncluir.setText("Novo");
        btnIncluir.setMaximumSize(new java.awt.Dimension(72, 23));
        btnIncluir.setMinimumSize(new java.awt.Dimension(72, 23));
        btnIncluir.setPreferredSize(new java.awt.Dimension(120, 120));
        btnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIncluirActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.setMaximumSize(new java.awt.Dimension(72, 23));
        btnExcluir.setMinimumSize(new java.awt.Dimension(72, 23));
        btnExcluir.setPreferredSize(new java.awt.Dimension(120, 120));
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnLimpar.setText("Limpar");
        btnLimpar.setMaximumSize(new java.awt.Dimension(72, 23));
        btnLimpar.setMinimumSize(new java.awt.Dimension(72, 23));
        btnLimpar.setPreferredSize(new java.awt.Dimension(120, 120));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Informações do Pedido"));
        jPanel2.setToolTipText("");

        txtData.setEditable(false);
        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        jLabel6.setText("Data:");

        jLabel13.setText("Código:");

        txtCod1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtCod1AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtCod1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCod1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCod1FocusLost(evt);
            }
        });
        txtCod1.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtCod1InputMethodTextChanged(evt);
            }
        });
        txtCod1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCod1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Tipo de Saída:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Venda de Mercadorias" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(txtCod1, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtCod1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TabProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição", "Quantidade", "Valor Unitário", "Valor Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabProdutos.getTableHeader().setReorderingAllowed(false);
        TabProdutos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabProdutosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabProdutos);

        txtSubtotal.setEditable(false);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Item"));
        jPanel4.setToolTipText("");

        jLabel7.setText("Descrição: ");

        txtDescItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDescItemmFocusLost(evt);
            }
        });
        txtDescItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescItemmActionPerformed(evt);
            }
        });

        txtValorItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtValorItemmActionPerformed(evt);
            }
        });

        jLabel10.setText("Valor Unitário:");

        jLabel15.setText("Código:");

        txtCodItemm.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtCodItemmAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtCodItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCodItemmFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCodItemmFocusLost(evt);
            }
        });
        txtCodItemm.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtCodItemmInputMethodTextChanged(evt);
            }
        });
        txtCodItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodItemmActionPerformed(evt);
            }
        });

        jLabel16.setText("Quantidade:");

        txtQtdeItemm.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                txtQtdeItemmAncestorMoved(evt);
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtQtdeItemmAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtQtdeItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtQtdeItemmFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtQtdeItemmFocusLost(evt);
            }
        });
        txtQtdeItemm.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtQtdeItemmInputMethodTextChanged(evt);
            }
        });
        txtQtdeItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQtdeItemmActionPerformed(evt);
            }
        });

        jLabel17.setText("Valor Total:");

        txtVTItemm.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtVTItemmAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtVTItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtVTItemmFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtVTItemmFocusLost(evt);
            }
        });
        txtVTItemm.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtVTItemmInputMethodTextChanged(evt);
            }
        });
        txtVTItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtVTItemmActionPerformed(evt);
            }
        });

        btnAddItem.setText("Adicionar Item");
        btnAddItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddItemActionPerformed(evt);
            }
        });

        jButton7.setText("Limpar Item");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtCodItemm, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                    .addComponent(txtQtdeItemm))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 13, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDescItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtVTItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtValorItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddItem, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDescItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(txtCodItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtValorItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel17)
                        .addComponent(txtVTItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnAddItem)
                        .addComponent(jButton7))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel16)
                        .addComponent(txtQtdeItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        TabProdutos1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição", "Quantidade", "Valor Unitário", "Valor Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(TabProdutos1);

        jMenu2.setText("Cadastro");

        jMenuItem2.setText("Cliente");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem2);

        jMenuBar1.add(jMenu2);

        jMenu1.setText("Consulta");

        jMenuItem1.setText("Pedidos");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnObter, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(158, 158, 158)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnObter, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeClienteActionPerformed

    private void txtCPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCPFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCPFActionPerformed

    private void txtCodClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodClienteActionPerformed

    private void btnObterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnObterActionPerformed
        
        if(txtCod1.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Digite um código!");
        }
        else{
            try{
                Integer.parseInt(txtCod1.getText());
            
                obter = true;
                Pedido pedido = new Pedido();
                PedidoDAO pedidoDAO = new PedidoDAO();
                try {
                    pedido = pedidoDAO.exibirPedido(Integer.parseInt(txtCod1.getText()));  

                    if(pedido.getDataPedido() != null){
                        txtData.setEditable(true);
                        df = new SimpleDateFormat("dd/MM/yyyy");
                        txtData.setText(df.format(pedido.getDataPedido()));
                        txtSubtotal.setText(String.valueOf(pedido.getValorPedido()));

                        btnExcluir.setEnabled(true);
                        btnAlterar.setEnabled(true);
                        btnIncluir.setEnabled(false);
                        btnObter.setEnabled(false);
                        
                        Cliente cliente = new Cliente();
                        ClienteDAO clienteDAO = new ClienteDAO();

                        try {
                            cliente = clienteDAO.exibirCliente(pedido.getCodigoCliente());
                            txtCodCliente.setText(String.valueOf(pedido.getCodigoCliente()));
                            txtNomeCliente.setText(cliente.getNomeCliente());
                            txtCPF.setText(cliente.getCpfCliente());

                        } catch (SQLException e) {
                            System.out.println(e);
                        }         


                        consultaTabela("select tb_itenspedido.cod_mercadoria, tb_mercadoria.desc_mercadoria, tb_itenspedido.qtde_produto, tb_itenspedido.valoruproduto, tb_itenspedido.valortproduto from tb_itenspedido INNER JOIN tb_mercadoria on tb_itenspedido.cod_mercadoria = tb_mercadoria.cod_mercadoria where cod_pedido = "+txtCod1.getText());

                        txtCod1.setEnabled(false);

                        DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();

                        int contador = tp.getRowCount();   
                        double valortotal = 0;

                        for (int i = 0 ; i < contador;  i++){           
                           valortotal += Double.parseDouble(tp.getValueAt(i, 4).toString());
                        }
                        txtSubtotal.setText(String.valueOf(valortotal));
                            
                        CamposEditF();

                    }
                    else{
                        txtCod1.setText("");
                        txtCod1.requestFocus();
                    }
                } catch (SQLException e) {
                    System.out.println(e);
                }
            }
            catch(NumberFormatException ex){
                txtCod1.requestFocus();
                txtCod1.setText("");
                CamposEditT();
                JOptionPane.showMessageDialog(this, "Digite um número inteiro!");
            }
            
           
            
        }
        

    }//GEN-LAST:event_btnObterActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        if(btnAlterar.getText().equals("Editar")){
            btnAlterar.setText("Alterar");
            CamposEditT();
        }
        else{

            if(txtCod1.getText().equals("")){
                JOptionPane.showMessageDialog(this, "Digite um código do pedido");
            }
            else if(txtCodCliente.getText().equals("")){
                JOptionPane.showMessageDialog(this, "Digite um código do cliente");
            }
            else{

                obter = false;

                int codigoTb1 = 0;
                int codigoTb2 = 0;            


                Pedido pedido = new Pedido();
                PedidoDAO pedidoDAO = new PedidoDAO();

                pedido.setCodigoPedido(Integer.parseInt(txtCod1.getText()));
                pedido.setCodigoCliente(Integer.parseInt(txtCodCliente.getText()));
                pedido.setValorPedido(Float.parseFloat(txtSubtotal.getText()));

                try {
                    pedidoDAO.alteraPedido(pedido);
                    JOptionPane.showMessageDialog(this, "Pedido Alterado com Sucesso");
                } catch (SQLException e) {
                    System.out.println(e);
                }

                DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
                int contador = tp.getRowCount();
                System.out.println("");
                MercadoriaDAO mercadoriaDAO = new MercadoriaDAO();

                if(contador > 0){


                    DefaultTableModel TabelaObter = (DefaultTableModel) TabProdutos1.getModel();

                    int contadorrr = 0;


                    int contadorr = TabelaObter.getRowCount();

                    System.out.println(contadorr);


                    for (int i = 0; i < contador; i++) {        

                        for (int a = 0; a < contadorr; a++) {

                            codigoTb1 = Integer.parseInt(tp.getValueAt(i, 0).toString());
                            codigoTb2 = Integer.parseInt(TabelaObter.getValueAt(a, 0).toString());
                            if(codigoTb1 == codigoTb2){
                                System.out.println(TabelaObter.getValueAt(a, 1).toString());
                                System.out.println(tp.getValueAt(i, 1).toString());

                                    int tabela = 0;
                                    tabela = Integer.parseInt(tp.getValueAt(i, 2).toString());
                                    int tabelaObter = 0;
                                    tabelaObter = Integer.parseInt(TabelaObter.getValueAt(a, 2).toString());
                                    int qtdeAtualizacao = 0;

                                    System.out.println(tp.getValueAt(i, 1).toString()+"qtde tabela"+tabela);
                                    System.out.println("qtde tabela obter "+tabelaObter);

                                    int recebeQtde = 0;




                                    qtdeAtualizacao = tabela - tabelaObter; 
                                    System.out.println(qtdeAtualizacao);

                                    qtdeAtualizacao +=  tabelaObter;     


                                    int codigoAtualizacao = Integer.parseInt(tp.getValueAt(i, 0).toString());

                                    try {
                                        mercadoriaDAO.alterarMercadoriaEntrada(-(tabela - tabelaObter), codigoAtualizacao);                                   

                                    } catch (SQLException e) {
                                        System.out.println("AQUI?"+e);
                                    }






                                    ItensPedidoDAO itensPedidoDAO = new ItensPedidoDAO();

                                    try{
                                        itensPedidoDAO.alteraQtdeItens(qtdeAtualizacao, Float.parseFloat(tp.getValueAt(i, 3).toString()), Float.parseFloat(tp.getValueAt(i, 4).toString()),Integer.parseInt(txtCod1.getText()), codigoAtualizacao);
                                        System.out.println("s");
                                    }catch(SQLException p){                                    
                                        System.out.println("b"+p);
                                    }





                            }
                        }   
                    }

                    //DefaultTableModel TabelaObter = (DefaultTableModel) TabProdutos1.getModel();
                    contador = tp.getRowCount();	
                    contadorr = TabelaObter.getRowCount();

                    for(int b = 0; b < contadorr; b++){
                        contadorrr = 0;
                        for(int c = 0; c < contador; c++){
                            if(!TabelaObter.getValueAt(b, 0).toString().equals(tp.getValueAt(c, 0).toString())){
                                contadorrr += 1;
                                if(contadorrr == contador){
                                    System.out.println("qq"+contadorrr);

                                    int codigoP = Integer.parseInt(TabelaObter.getValueAt(b, 0).toString());
                                    int qtdeMenos =  0;

                                    ItensPedido itensPedido = new ItensPedido();
                                    ItensPedidoDAO itensPedidoDAO = new ItensPedidoDAO();



                                    itensPedido.setCodigoPedido(Integer.parseInt(txtCod1.getText()));
                                    itensPedido.setCodigoMercadoria(codigoP);

                                    try{
                                        itensPedidoDAO.removeItem(itensPedido);
                                        mercadoriaDAO.alterarMercadoriaEntrada(Integer.parseInt(TabelaObter.getValueAt(b, 2).toString()), codigoP);
                                    }catch(SQLException ex){
                                        System.out.println("a"+ex);
                                    }

                                    //qtdeMenos -= Integer.parseInt(TabelaObter.getValueAt(b, 2).toString());
                                    //System.out.println(codigoP + " "+TabelaObter.getValueAt(b, 1).toString()+" " +qtdeMenos);
                                    contadorrr = 0;

                                }

                            }         
                        }

                    }
                    contador = tp.getRowCount();	
                    contadorr = TabelaObter.getRowCount();                    
                    if(contador > contadorr){
                            for(int b = 0; b < contador; b++){
                                contadorrr = 0;
                                for(int c = 0; c < contadorr; c++){
                                    if(!tp.getValueAt(b, 0).toString().equals(TabelaObter.getValueAt(c, 0).toString())){
                                        contadorrr += 1;
                                        if(contadorrr == contadorr){
                                            System.out.println("qq"+contadorrr);

                                            int codigoP = Integer.parseInt(tp.getValueAt(b, 0).toString());
                                            int qtdeMenos =  0;


                                            ItensPedido itensPedido = new ItensPedido();
                                            ItensPedidoDAO itensPedidoDAO = new ItensPedidoDAO();

                                            itensPedido.setCodigoPedido(pedido.getCodigoPedido());
                                            itensPedido.setCodigoMercadoria(codigoP);
                                            itensPedido.setQtdeProduto(Integer.parseInt(tp.getValueAt(b, 2).toString()));
                                            itensPedido.setValorUniProduto(Float.parseFloat(tp.getValueAt(b, 3).toString()));
                                            itensPedido.setValorTotProduto(Float.parseFloat(tp.getValueAt(b, 4).toString()));                


                                            try{
                                                itensPedidoDAO.inserirItens(itensPedido);
                                                mercadoriaDAO.alterarMercadoriaEntrada(Integer.parseInt(tp.getValueAt(b, 2).toString()), codigoP);
                                                System.out.println("");
                                            }catch(SQLException ex){
                                                System.out.println("a"+ex);
                                            }

                                            //qtdeMenos -= Integer.parseInt(TabelaObter.getValueAt(b, 2).toString());
                                            //System.out.println(codigoP + " "+TabelaObter.getValueAt(b, 1).toString()+" " +qtdeMenos);
                                            contadorrr = 0;

                                        }
                                    }         
                                }
                            }
                    }    
                    else{
                        System.out.println("CASSETA");
                    }
                }
                LimpaCampos();
                LimpaTabela();
                btnAlterar.setText("Editar");
                btnObter.setEnabled(true);
                btnExcluir.setEnabled(false);
            }    
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIncluirActionPerformed
        
        Pedido pedido = new Pedido();
        PedidoDAO pedidoDAO = new PedidoDAO();               

        
        
        if(btnIncluir.getText().equals("Novo")){
            btnIncluir.setText("Incluir");
            txtCod1.setEnabled(false);
            txtCodCliente.requestFocus();
            try {
                txtCod1.setText(String.valueOf(pedidoDAO.listarUltimoCod()));            
            } catch (SQLException e) {
                System.out.println(e);
            }
            
            btnObter.setEnabled(false);
            btnAlterar.setEnabled(false);
            btnExcluir.setEnabled(false);
            
            CamposEditT();
        }
        else{
            if(txtCodCliente.getText().equals("")){
                JOptionPane.showMessageDialog(this, "Adicione o cliente!", "Atenção!", JOptionPane.INFORMATION_MESSAGE);
            }
            else{           
                            
                

                
                DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
                int contador = TabProdutos.getRowCount();
                
                if(contador > 0){
                    
                    pedido.setCodigoCliente(Integer.parseInt(txtCodCliente.getText()));

                    Date dataUtil = hoje;
                    java.sql.Date dataSql = null;

                    df = new SimpleDateFormat("dd/MM/yyyy");

                    dataUtil = new java.sql.Date(dataUtil.getTime());
                    dataSql = (java.sql.Date) dataUtil;

                    pedido.setDataPedido(dataSql);
                    pedido.setValorPedido(Float.parseFloat(txtSubtotal.getText()));

                    try {

                        pedidoDAO.inserirPedido(pedido);                    
                    } catch (SQLException e) {
                        System.out.println(e);
                    }                    
                    
                    for(int i = 0; i < contador; i++){                        
                        ItensPedido itensPedido = new ItensPedido();
                        ItensPedidoDAO itensPedidoDAO = new ItensPedidoDAO();
                        
                        itensPedido.setCodigoPedido(Integer.parseInt(txtCod1.getText()));
                        itensPedido.setCodigoMercadoria(Integer.parseInt(tp.getValueAt(i, 0).toString()));
                        itensPedido.setQtdeProduto(Integer.parseInt(tp.getValueAt(i, 2).toString()));
                        itensPedido.setValorUniProduto(Double.parseDouble(tp.getValueAt(i, 3).toString()));
                        itensPedido.setValorTotProduto(Double.parseDouble(tp.getValueAt(i, 4).toString()));
                        
                        try {                            
                            itensPedidoDAO.inserirItens(itensPedido);
                            
                            MercadoriaDAO mercadoriaDAO = new MercadoriaDAO();
                            mercadoriaDAO.alterarMercadoriaEntrada(-Integer.parseInt(tp.getValueAt(i, 2).toString()), Integer.parseInt(tp.getValueAt(i, 0).toString()));
                            
                        } catch (Exception e) {
                        }
                        
                    }
                    
                    JOptionPane.showMessageDialog(null, "Pedido "+txtCod1.getText()+" Cadastrado com sucesso", "Cadastro de Pedidos", JOptionPane.INFORMATION_MESSAGE);
                    btnIncluir.setText("Novo");
                    LimpaCampos();
                    LimpaTabela();
                }
                else{
                    JOptionPane.showMessageDialog(this, "Adicione ao menos um produto!");
                    txtCodItemm.requestFocus();
                }
                
                
                
            }
           
            
            
            
            
            
            
            

        }

        
      
        
        
    }//GEN-LAST:event_btnIncluirActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed

        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir o pedido?", "Atenção!", JOptionPane.YES_NO_OPTION);
        
        if(resposta == 0){
            DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
            int contador = tp .getRowCount();

            try{
                for(int i = 0; i < contador; i++){
                    try{
                    ItensPedido itensPedido = new ItensPedido();
                    ItensPedidoDAO itensPedidoDAO = new ItensPedidoDAO();
                    MercadoriaDAO mercadoriaDAO = new MercadoriaDAO();

                    itensPedido.setCodigoMercadoria(Integer.parseInt(tp.getValueAt(i, 0).toString()));
                    itensPedido.setCodigoPedido(Integer.parseInt(txtCod1.getText()));

                    mercadoriaDAO.alterarMercadoriaEntrada(Integer.parseInt(tp.getValueAt(i, 2).toString()), Integer.parseInt(tp.getValueAt(i, 0).toString()));
                    itensPedidoDAO.removeItem(itensPedido);
                    }catch(SQLException e){
                        System.out.println(e);
                    }
                }
                PedidoDAO pedidoDAO = new PedidoDAO();

                pedidoDAO.excluiPedido(Integer.parseInt(txtCod1.getText()));
            }catch(SQLException e){
                System.out.println(e);
            }
            btnLimpar.doClick();
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        LimpaCampos();
        LimpaTabela();
        
    }//GEN-LAST:event_btnLimparActionPerformed

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus


        if(gainedInfomation == true){
            gainedInfomation = false;
            txtCod1.setText(String.valueOf(ConsultaPedidos.passaCodigoPedido));
            btnObter.doClick();
        }

        if(gained == true){
            gained = false;
            if(passaNome != null){
                try{
                    Integer.parseInt(passaNome);

                    txtCodCliente.setText(passaNome);
                    passaNome = "";

                    Cliente cliente = new Cliente();
                    ClienteDAO clienteDao = new ClienteDAO();



                    try {
                        cliente = clienteDao.exibirCliente(Integer.parseInt(txtCodCliente.getText()));
                        txtNomeCliente.setText(cliente.getNomeCliente());

                    } catch (SQLException ex) {
                        Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                    if(!txtNomeCliente.getText().equals("")){
                        txtCPF.setText(cliente.getCpfCliente());
                        txtCodCliente.setEditable(false);
                        txtNomeCliente.setEditable(false);
                        txtCPF.setEditable(false);

                    }            
                }catch(NumberFormatException ex){

                }
            }
            if(passaDescricao != null){
                try{
                    Integer.parseInt(passaDescricao);

                    txtCodItemm.setText(passaDescricao);
                    passaDescricao = "";

                    Mercadoria produto = new Mercadoria();
                    MercadoriaDAO produtoDao = new MercadoriaDAO();



                    try {
                        produto = produtoDao.exibirMercadoria(Integer.parseInt(txtCodItemm.getText()));
                        txtDescItemm.setText(produto.getDescMercadoria());
                        txtQtdeItemm.requestFocus();
                    } catch (SQLException ex) {
                        Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                    if(!txtDescItemm.getText().equals("")){
                        txtValorItemm.setText(String.valueOf(produto.getPrecovMercadoria()));
                        txtCodItemm.setEditable(false);
                        txtDescItemm.setEditable(false);


                    }            
                }catch(NumberFormatException ex){
                    System.out.println(ex);
                    
                    txtCodItemm.requestFocus();
                }
            }        
      
        }
       
    }//GEN-LAST:event_formWindowGainedFocus

    private void formFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_formFocusGained
        
        
    }//GEN-LAST:event_formFocusGained

    private void txtCodClienteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodClienteFocusLost
        if(!txtCodCliente.getText().equals("")){
            try{
                Integer.parseInt(txtCodCliente.getText());
            
                Cliente cliente = new Cliente();
                ClienteDAO clienteDao = new ClienteDAO();

                try {
                    cliente = clienteDao.exibirCliente(Integer.parseInt(txtCodCliente.getText()));
                    if(cliente.getNomeCliente() != null){
                        txtNomeCliente.setText(cliente.getNomeCliente());
                        txtCPF.setText(cliente.getCpfCliente());
                        txtCodCliente.setEditable(false);
                        txtNomeCliente.setEditable(false);
                        txtCPF.setEditable(false);
                        txtCodItemm.requestFocus();
                    }            
                    else{
                        txtCodCliente.requestFocus();
                        txtCodCliente.setText("");
                    }
                    

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Cliente não existe!"+ex);


                }

            }catch(NumberFormatException ex){
                txtCodCliente.requestFocus();
                txtCodCliente.setText("");
                JOptionPane.showMessageDialog(this, "Digite um número inteiro\npara o código do cliente!");
            }
            
            
        }       
        
                
        


    }//GEN-LAST:event_txtCodClienteFocusLost

    private void txtCodClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodClienteFocusGained

    }//GEN-LAST:event_txtCodClienteFocusGained

    private void txtCodClienteInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtCodClienteInputMethodTextChanged

    }//GEN-LAST:event_txtCodClienteInputMethodTextChanged

    private void txtCodClienteAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtCodClienteAncestorAdded
        /**
        if(!txtCod.getText().equals("")){
            btnIncluir.setEnabled(false);
            txtCod.setEnabled(false);

            Cliente recebeCliente = new Cliente();
            try {
                recebeCliente = clienteDao.exibirCliente(Integer.parseInt(txtCod.getText()));
            } catch (SQLException ex) {
                Logger.getLogger(Cad_Cliente.class.getName()).log(Level.SEVERE, null, ex);
                txtCod.setEnabled(true);

            }
            txtNome.setText(recebeCliente.getNomeCliente());
            txtEmail.setText(recebeCliente.getEmailCliente());
            txtApelido.setText(recebeCliente.getApelidoCliente());
            txtEndereco.setText(recebeCliente.getEnderecoCliente());
            txtBairro.setText(recebeCliente.getBairroCliente());
            txtCidade.setText(recebeCliente.getCidadeCliente());
            cboEstado.setSelectedItem(recebeCliente.getEstadoCliente());
            txtCEP.setText(recebeCliente.getCepCliente());
            txtTelefone1.setText(recebeCliente.getTelefone1Cliente());
            txtTelefone2.setText(recebeCliente.getTelefone2Cliente());
            txtData.setText(recebeCliente.getDataNascimentoCliente());
            txtCPF.setText(String.valueOf(recebeCliente.getCpfCliente()));
            txtRG.setText(String.valueOf(recebeCliente.getRgCliente()));
            txtCNPJ.setText(String.valueOf(recebeCliente.getCnpjCliente()));
            txtIE.setText(String.valueOf(recebeCliente.getIeCliente()));
        }
        * */
    }//GEN-LAST:event_txtCodClienteAncestorAdded

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
       
    }//GEN-LAST:event_formWindowClosed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        ConsultaPedidos consultaPedidos = new ConsultaPedidos();
        consultaPedidos.setVisible(true);
        pedido = true;
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void txtCod1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtCod1AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCod1AncestorAdded

    private void txtCod1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCod1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCod1FocusGained

    private void txtCod1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCod1FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCod1FocusLost

    private void txtCod1InputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtCod1InputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCod1InputMethodTextChanged

    private void txtCod1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCod1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCod1ActionPerformed

    private void txtDescItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescItemmActionPerformed

    private void txtValorItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtValorItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtValorItemmActionPerformed

    private void txtCodItemmAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtCodItemmAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmAncestorAdded

    private void txtCodItemmFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodItemmFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmFocusGained

    private void txtCodItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodItemmFocusLost
        if(!txtCodItemm.getText().equals("")){
            try{
                Integer.parseInt(txtCodItemm.getText());
            
                
            
            Mercadoria item = new Mercadoria();
            MercadoriaDAO mercadoriaDao = new MercadoriaDAO();



            try {
                item = mercadoriaDao.exibirMercadoria(Integer.parseInt(txtCodItemm.getText()));
                System.out.println(item.getDescMercadoria());
                txtDescItemm.setText(item.getDescMercadoria());

            } catch (SQLException ex) {
                Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);


            }
            if(!txtDescItemm.getText().equals("")){
                    
                txtQtdeItemm.requestFocus();
                    txtValorItemm.setText(String.valueOf(item.getPrecovMercadoria()));
                    txtCodItemm.setEditable(false);
                    txtDescItemm.setEditable(false);

            }
            }catch(NumberFormatException ex){
                txtCodItemm.requestFocus();
                txtCodItemm.setText("");
                JOptionPane.showMessageDialog(this, "Digite um número inteiro\npara o código do produto!");
            }
            
        }
    }//GEN-LAST:event_txtCodItemmFocusLost

    private void txtCodItemmInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtCodItemmInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmInputMethodTextChanged

    private void txtCodItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmActionPerformed

    private void txtQtdeItemmAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtQtdeItemmAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmAncestorAdded

    private void txtQtdeItemmFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQtdeItemmFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmFocusGained

    private void txtQtdeItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQtdeItemmFocusLost
        if(!txtCodItemm.getText().equals("")){
            float valorUni = 0;
            int qtde = 0;
            try{
                valorUni = Float.parseFloat(txtValorItemm.getText().replace(",", "."));
                qtde = Integer.parseInt(txtQtdeItemm.getText());
            }catch(NumberFormatException ex){
                
            }
            int qtdeMercadoria = 0;
            
            MercadoriaDAO mercadoriaDAO = new MercadoriaDAO();
            
            try {
                qtdeMercadoria = mercadoriaDAO.mostraQtdeMercadoria(Integer.parseInt(txtCodItemm.getText()));
            } catch (SQLException e) {
                System.out.println(e);
            }
            if(qtdeMercadoria - pegaQtdeTab < qtde && obter == true){
                JOptionPane.showMessageDialog(this, "Quantidade adicionada menor que a disponível no estoque!\nContate o administrador e informe o erro", "Atenção!", JOptionPane.OK_OPTION);
               
                
            }            
            else if(qtdeMercadoria < qtde){
                JOptionPane.showMessageDialog(this, "Quantidade adicionada menor que a disponível no estoque!\nContate o administrador e informe o erro", "Atenção!", JOptionPane.OK_OPTION);

            }
            if(qtde > 0){
                txtVTItemm.setText(String.valueOf(valorUni * qtde));    
            }

            
        }
    }//GEN-LAST:event_txtQtdeItemmFocusLost

    private void txtQtdeItemmInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtQtdeItemmInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmInputMethodTextChanged

    private void txtQtdeItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQtdeItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmActionPerformed

    private void txtVTItemmAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtVTItemmAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVTItemmAncestorAdded

    private void txtVTItemmFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtVTItemmFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVTItemmFocusGained

    private void txtVTItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtVTItemmFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVTItemmFocusLost

    private void txtVTItemmInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtVTItemmInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVTItemmInputMethodTextChanged

    private void txtVTItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtVTItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVTItemmActionPerformed

    private void btnAddItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddItemActionPerformed
          
        if(txtCodItemm.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Digite um produto para adicionar");
            txtCodItemm.requestFocus();
        }
        else if(!txtQtdeItemm.getText().equals("")){
            try{
                int qtde = Integer.parseInt(txtQtdeItemm.getText());
                
                if(qtde > 0){
                    boolean produtoIgual = false;
                    double valortotal = 0;

                    DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
                    int contador = tp.getRowCount();


                    for (int i = 0 ; i < contador;  i++){

                        if(txtCodItemm.getText().equals(tp.getValueAt(i, 0).toString())){
                            produtoIgual = true;
                            JOptionPane.showMessageDialog(null, "Produto já adicionado!", "Atenção!", JOptionPane.OK_OPTION);
                            LimpaItem();


                        }

                    }

                    if(produtoIgual == false){
                        tp.addRow(new Object[]{String.valueOf(txtCodItemm.getText()), String.valueOf(txtDescItemm.getText()),  String.valueOf(txtQtdeItemm.getText()), String.valueOf(txtValorItemm.getText().replace(",", ".")), String.valueOf(txtVTItemm.getText().replace(",", "."))});        
                    }

                   contador = tp.getRowCount();      



                   for (int i = 0 ; i < contador;  i++){           
                      valortotal += Double.parseDouble(tp.getValueAt(i, 4).toString());
                   }
                   txtSubtotal.setText(String.valueOf(valortotal));

                   LimpaItem();      
                }
                else{
                    JOptionPane.showMessageDialog(this, "A quantidade deve ser maior que 0");    
                }
            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Digite um número inteiro");
                txtQtdeItemm.requestFocus();
                txtQtdeItemm.setText("");
            }
            
        }
        else{
            JOptionPane.showMessageDialog(this, "Informe a quantidade!");
            txtQtdeItemm.requestFocus();
        }
    }//GEN-LAST:event_btnAddItemActionPerformed

    private void btnLimpaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpaClienteActionPerformed
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente limpar os campos do cliente?", "Atenção!", JOptionPane.YES_NO_OPTION);
        
        if(resposta == 0){        
            LimpaCliente();
        }
    }//GEN-LAST:event_btnLimpaClienteActionPerformed

    private void txtNomeClienteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtNomeClienteFocusLost

        if(txtCodCliente.getText().equals("") && !txtNomeCliente.getText().equals("")){
            ConsultaCliente consultaCliente = new ConsultaCliente();
            consultaCliente.setVisible(true);           
            passaNome = txtNomeCliente.getText();
            
        }
    }//GEN-LAST:event_txtNomeClienteFocusLost

    private void txtDescItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDescItemmFocusLost
        if(txtCodItemm.getText().equals("") && !txtDescItemm.getText().equals("")){
            ConsultaMercadoria consultaMercadoria = new ConsultaMercadoria();
            consultaMercadoria.setVisible(true);           
            passaDescricao = txtDescItemm.getText();
            
        }
    }//GEN-LAST:event_txtDescItemmFocusLost

    private void TabProdutosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabProdutosMouseClicked

        DefaultTableModel tp = (DefaultTableModel) TabProdutos.getModel();
        linha = TabProdutos.getSelectedRow();
        
        linhaEsq = TabProdutos.rowAtPoint(evt.getPoint());
        
        if (evt.getButton() == evt.BUTTON3 && TabProdutos.isEnabled()) { // Clique com botao direito do mouse.             
            jPopupMenu1.show(TabProdutos, evt.getX(), evt.getY());
        }
        
        if(evt.getClickCount() == 2){
            txtCodItemm.setText(TabProdutos.getValueAt(linha, 0).toString());
            txtDescItemm.setText(TabProdutos.getValueAt(linha, 1).toString());
            txtQtdeItemm.setText(TabProdutos.getValueAt(linha, 2).toString());
            pegaQtdeTab = Integer.parseInt(TabProdutos.getValueAt(linha, 2).toString());
            txtValorItemm.setText(TabProdutos.getValueAt(linha, 3).toString());
            txtVTItemm.setText(TabProdutos.getValueAt(linha, 4).toString());
            
            txtQtdeItemm.requestFocus();
            txtCodItemm.setEditable(false);
            txtDescItemm.setEditable(false);
            
            tp.removeRow(linha);            
        }
    }//GEN-LAST:event_TabProdutosMouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        LimpaItem();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        Cad_Cliente cad_Cliente = new Cad_Cliente();
        cad_Cliente.setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void txtQtdeItemmAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtQtdeItemmAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmAncestorMoved

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cad_Pedido().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TabProdutos;
    private javax.swing.JTable TabProdutos1;
    private javax.swing.JButton btnAddItem;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnIncluir;
    private javax.swing.JButton btnLimpaCliente;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnObter;
    private javax.swing.ButtonGroup grupoPessoa;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtCPF;
    protected javax.swing.JTextField txtCod1;
    protected javax.swing.JTextField txtCodCliente;
    protected javax.swing.JTextField txtCodItemm;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtDescItemm;
    private javax.swing.JTextField txtNomeCliente;
    protected javax.swing.JTextField txtQtdeItemm;
    private javax.swing.JTextField txtSubtotal;
    protected javax.swing.JTextField txtVTItemm;
    private javax.swing.JTextField txtValorItemm;
    // End of variables declaration//GEN-END:variables
}

