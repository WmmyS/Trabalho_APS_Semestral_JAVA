/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframes;

import banco_dados.Conexao;
import classes.Cliente;
import classes.ItensNota;
import classes.ItensPedido;
import classes.Mercadoria;
import classes.Pedido;
import com.sun.glass.ui.Window.Level;
import dao.ClienteDAO;
import dao.ItensPedidoDAO;
import dao.MercadoriaDAO;
import dao.PedidoDAO;
import imagens.Icone;
import java.awt.Color;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



/**
 *
 * @author Lucas Corrêa
 */
public class ConsultaEntSaida extends javax.swing.JFrame {



    int linha = -1;
    Conexao conecta;
    
    public static String passaDescricao = null;
    public static Boolean cadPedido;
    public static Boolean gained = false;
    
    DefaultTableModel tp;
    DefaultTableModel TabelaObter;     
    
    /**
     * Creates new form Cad_Cliente
     */
    
    boolean primeiroItem = true;
    int pegaQtdeTab = 0;
    boolean obter = false;
    
    private boolean inteiro(double num) {
	int aux = (int)num;
	
	return (((double)aux) == num);
    }
    

    
    public void mostra(int cod){
        jLabel1.setText(String.valueOf(cod));
        
    }
    
    public void CamposEditT(){
        
        txtDescItemm.setEditable(true);
        txtQtdeItemm.setEditable(true);
        txtCodItemm.setEditable(true);
        
    }
    
    public void CamposEditF(){
        
        txtDescItemm.setEditable(false);
        txtQtdeItemm.setEditable(false);
        txtCodItemm.setEditable(false);
        
    }    
    
    public void LimpaItem(){
        txtCodItemm.setText("");
        txtDescItemm.setText("");
        txtQtdeItemm.setText("");
        txtCodItemm.setEnabled(true);
        txtDescItemm.setEnabled(true);
    }
    

    public void LimpaCampos(){

        txtqtdeS.setText("");



       
              
    }
    
    public void LimpaTabela(){
        DefaultTableModel tp = (DefaultTableModel) TabEntrada.getModel();
        DefaultTableModel tp1 = (DefaultTableModel) TabSaida.getModel();
        tp.setNumRows(0);
        tp1.setNumRows(0);
    }
    
   public void consultaTabelaEnt(String SQL){

        DefaultTableModel tEntrada = (DefaultTableModel) TabEntrada.getModel();
        
        tEntrada.setNumRows(0);
        
        int qtde = 0;
        

        conecta.executaSQL(SQL);
        System.out.println(SQL);
        
        try{
            conecta.rs.first();
            do{
               SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
               tEntrada.addRow(new Object[]{conecta.rs.getInt("cod_nota"),conecta.rs.getString("nome_fornecedor"), conecta.rs.getString("desc_mercadoria"), conecta.rs.getInt("qtde_produto"), conecta.rs.getDouble("valoraproduto"), df.format(conecta.rs.getDate("data_nota"))});
               qtde += conecta.rs.getInt("qtde_produto");
                
            }while (conecta.rs.next());
            
            txtqtdeE.setText(String.valueOf(qtde));
                    
        }catch(SQLException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(null, "Produto não consta em nenhuma entrada nesse período", "Atenção!", JOptionPane.ERROR_MESSAGE);
            txtqtdeE.setText(String.valueOf(qtde));
        } 
        
        
        
        
    }    
   
   public void consultaTabelaSaida(String SQL){

        DefaultTableModel tSaida = (DefaultTableModel) TabSaida.getModel(); 
        tSaida.setNumRows(0);
        int qtde = 0;

        conecta.executaSQL(SQL);
        
        try{
            conecta.rs.first();
            
            do{
                SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                tSaida.addRow(new Object[]{conecta.rs.getInt("cod_pedido"),conecta.rs.getString("nome_cliente"),conecta.rs.getString("desc_mercadoria"), conecta.rs.getInt("qtde_produto"), conecta.rs.getDouble("valoruproduto"), df.format(conecta.rs.getDate("data_pedido"))});
                qtde += conecta.rs.getInt("qtde_produto");
                
            }while (conecta.rs.next());
                    
            
            txtqtdeS.setText(String.valueOf(qtde));
            
        }catch(SQLException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(null, "Produto não consta em nenhum pedido nesse período", "Atenção!", JOptionPane.ERROR_MESSAGE);
            txtqtdeS.setText(String.valueOf(qtde));
        } 
        
        
    }   
    
    public ConsultaEntSaida() {
        initComponents();
        
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        txtDataI.setText(df.format(new Date()));
        txtDataF.setText(df.format(new Date()));
        
        Icone icone = new Icone();
        this.setIconImage(icone.getIconTitulo());        
      
        
        conecta = new Conexao();
        this.setBackground(Color.white);


        
        
        
  
        
        
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupoPessoa = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabEntrada = new javax.swing.JTable();
        txtqtdeS = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtDescItemm = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtCodItemm = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtQtdeItemm = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        btnConsultar = new javax.swing.JButton();
        txtDataI = new javax.swing.JFormattedTextField();
        txtDataF = new javax.swing.JFormattedTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabProdutos1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        TabSaida = new javax.swing.JTable();
        txtqtdeE = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Entrada e Saída de Produtos");
        addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                formFocusGained(evt);
            }
        });
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        TabEntrada.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Nota", "Fornecedor", "Mercadoria", "Quantidade", "Valor Unitário", "Data"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabEntrada.getTableHeader().setReorderingAllowed(false);
        TabEntrada.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabEntradaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabEntrada);

        txtqtdeS.setEditable(false);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Produto"));
        jPanel4.setToolTipText("");

        jLabel7.setText("Descrição: ");

        txtDescItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDescItemmFocusLost(evt);
            }
        });
        txtDescItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescItemmActionPerformed(evt);
            }
        });

        jLabel15.setText("Código:");

        txtCodItemm.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtCodItemmAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtCodItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtCodItemmFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCodItemmFocusLost(evt);
            }
        });
        txtCodItemm.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtCodItemmInputMethodTextChanged(evt);
            }
        });
        txtCodItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodItemmActionPerformed(evt);
            }
        });

        jLabel16.setText("Quantidade:");

        txtQtdeItemm.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtQtdeItemmAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        txtQtdeItemm.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtQtdeItemmFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtQtdeItemmFocusLost(evt);
            }
        });
        txtQtdeItemm.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtQtdeItemmInputMethodTextChanged(evt);
            }
        });
        txtQtdeItemm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQtdeItemmActionPerformed(evt);
            }
        });

        jButton7.setText("Limpar Item");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        try {
            txtDataI.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            txtDataF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel3.setText("Data Inicial:");

        jLabel4.setText("Data Final:");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(18, 18, 18)
                        .addComponent(txtCodItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(txtDescItemm, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel16)
                        .addGap(18, 18, 18)
                        .addComponent(txtQtdeItemm, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDataI, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDataF, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDescItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(txtCodItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(txtQtdeItemm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(btnConsultar)
                    .addComponent(txtDataI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDataF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        TabProdutos1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição", "Quantidade", "Valor Unitário", "Valor Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(TabProdutos1);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Entrada");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Saída");

        TabSaida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Pedido", "Cliente", "Produto", "Quantidade", "Valor Unitário", "Data"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabSaida.getTableHeader().setReorderingAllowed(false);
        TabSaida.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabSaidaMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(TabSaida);

        txtqtdeE.setEditable(false);

        jLabel5.setText("Entrou:");

        jLabel6.setText("Saiu:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(461, 461, 461)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addGap(165, 165, 165)
                                            .addComponent(jLabel5)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(txtqtdeE, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtqtdeS, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(355, 355, 355)
                        .addComponent(jLabel1)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtqtdeE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(21, 21, 21)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtqtdeS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(48, 48, 48))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus
        if(gained == true){
            gained = false;
            
            if(passaDescricao != null){
                try{
                    Integer.parseInt(passaDescricao);

                    txtCodItemm.setText(passaDescricao);
                    passaDescricao = "";

                    Mercadoria produto = new Mercadoria();
                    MercadoriaDAO produtoDao = new MercadoriaDAO();



                    try {
                        produto = produtoDao.exibirMercadoria(Integer.parseInt(txtCodItemm.getText()));
                        txtDescItemm.setText(produto.getDescMercadoria());
                        txtQtdeItemm.setText(String.valueOf(produto.getQtdeMercadoria()));
                        txtQtdeItemm.requestFocus();
                    } catch (SQLException ex) {
                        Logger.getLogger(Cad_Pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    }
                    if(!txtDescItemm.getText().equals("")){
                        
                        txtCodItemm.setEditable(false);
                        txtDescItemm.setEditable(false);


                    }            
                }catch(NumberFormatException ex){
                    System.out.println(ex);
                    LimpaItem();
                    txtDescItemm.requestFocus();
                }
            }        
      
        }       
    }//GEN-LAST:event_formWindowGainedFocus

    private void formFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_formFocusGained
        
        
    }//GEN-LAST:event_formFocusGained

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
       
    }//GEN-LAST:event_formWindowClosed

    private void txtDescItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescItemmActionPerformed

    private void txtCodItemmAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtCodItemmAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmAncestorAdded

    private void txtCodItemmFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodItemmFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmFocusGained

    private void txtCodItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCodItemmFocusLost
        if(!txtCodItemm.getText().equals("")){
            try{
                Integer.parseInt(txtCodItemm.getText());
            
                Mercadoria item = new Mercadoria();
                MercadoriaDAO mercadoriaDao = new MercadoriaDAO();

                try {
                    item = mercadoriaDao.exibirMercadoria(Integer.parseInt(txtCodItemm.getText()));
                    if(item.getDescMercadoria() != null){
                        
                        txtDescItemm.setText(item.getDescMercadoria());
                        txtQtdeItemm.setText(String.valueOf(item.getQtdeMercadoria()));
                        txtQtdeItemm.setEditable(false);
                        txtCodItemm.setEnabled(false);
                        txtDescItemm.setEnabled(false);
                    }
                    else{
                        txtCodItemm.setText("");
                        txtCodItemm.requestFocus();
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(ConsultaEntSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);


                }

            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(this, "Número digitado incorretamente!");
                txtCodItemm.setText("");
                txtCodItemm.requestFocus();
            }
            
            
        }
    }//GEN-LAST:event_txtCodItemmFocusLost

    private void txtCodItemmInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtCodItemmInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmInputMethodTextChanged

    private void txtCodItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodItemmActionPerformed

    private void txtQtdeItemmAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtQtdeItemmAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmAncestorAdded

    private void txtQtdeItemmFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQtdeItemmFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmFocusGained

    private void txtQtdeItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtQtdeItemmFocusLost
        
    }//GEN-LAST:event_txtQtdeItemmFocusLost

    private void txtQtdeItemmInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtQtdeItemmInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmInputMethodTextChanged

    private void txtQtdeItemmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQtdeItemmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtdeItemmActionPerformed

    private void txtDescItemmFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDescItemmFocusLost
        if(txtCodItemm.getText().equals("") && !txtDescItemm.getText().equals("")){
            ConsultaMercadoria consultaMercadoria = new ConsultaMercadoria();
            consultaMercadoria.setVisible(true);           
            passaDescricao = txtDescItemm.getText();
            
        }
    }//GEN-LAST:event_txtDescItemmFocusLost

    private void TabEntradaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabEntradaMouseClicked

    }//GEN-LAST:event_TabEntradaMouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        LimpaItem();
        LimpaCampos();
        LimpaTabela();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void TabSaidaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabSaidaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_TabSaidaMouseClicked

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        if(!txtCodItemm.getText().equals("")){
            Date dataUtilI = null;        
            Date dataUtilF = null;

            SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            try {
                dataUtilI = df.parse(txtDataI.getText());  
                dataUtilF = df.parse(txtDataF.getText());  
            } catch (Exception e) {
            }

            java.sql.Date dataSqlI = null;
            java.sql.Date dataSqlF = null;

            dataUtilI = new java.sql.Date(dataUtilI.getTime());
            dataUtilF = new java.sql.Date(dataUtilF.getTime());
            dataSqlI = (java.sql.Date) dataUtilI;
            dataSqlF = (java.sql.Date) dataUtilF;


            consultaTabelaEnt("select tb_itensnota.cod_nota, tb_fornecedor.nome_fornecedor, tb_mercadoria.desc_mercadoria, tb_itensnota.qtde_produto, tb_itensnota.valoraproduto, tb_notaentrada.data_nota from tb_itensnota inner join tb_mercadoria on tb_itensnota.cod_mercadoria = tb_mercadoria.cod_mercadoria inner join tb_notaentrada on tb_itensnota.cod_nota = tb_notaentrada.cod_nota inner join tb_fornecedor on tb_itensnota.cod_fornecedor = tb_fornecedor.cod_fornecedor where (tb_notaentrada.data_nota BETWEEN '"+dataSqlI+"' AND '"+dataSqlF+"') and tb_itensnota.cod_fornecedor = tb_notaentrada.cod_fornecedor and tb_itensnota.cod_mercadoria = "+txtCodItemm.getText()+" order by tb_notaentrada.data_nota");
            consultaTabelaSaida("select tb_itenspedido.cod_pedido, tb_cliente.nome_cliente, tb_mercadoria.desc_mercadoria, tb_itenspedido.qtde_produto, tb_itenspedido.valoruproduto, tb_pedido.data_pedido from tb_itenspedido inner join tb_pedido on tb_itenspedido.cod_pedido = tb_pedido.cod_pedido inner join tb_cliente on tb_pedido.cod_cliente = tb_cliente.cod_cliente inner join tb_mercadoria on tb_itenspedido.cod_mercadoria = tb_mercadoria.cod_mercadoria where (tb_pedido.data_pedido BETWEEN '"+dataSqlI+"' AND '"+dataSqlF+"') and tb_itenspedido.cod_mercadoria = "+txtCodItemm.getText()+" order by tb_pedido.data_pedido");            
            
        }
        else{
            JOptionPane.showMessageDialog(this, "Informe a mercadoria!");
            txtCodItemm.requestFocus();
        }
        
    }//GEN-LAST:event_btnConsultarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaEntSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaEntSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaEntSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaEntSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaEntSaida().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TabEntrada;
    private javax.swing.JTable TabProdutos1;
    private javax.swing.JTable TabSaida;
    private javax.swing.JButton btnConsultar;
    private javax.swing.ButtonGroup grupoPessoa;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    protected javax.swing.JTextField txtCodItemm;
    private javax.swing.JFormattedTextField txtDataF;
    private javax.swing.JFormattedTextField txtDataI;
    private javax.swing.JTextField txtDescItemm;
    protected javax.swing.JTextField txtQtdeItemm;
    private javax.swing.JTextField txtqtdeE;
    private javax.swing.JTextField txtqtdeS;
    // End of variables declaration//GEN-END:variables
}

